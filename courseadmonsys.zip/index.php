<!DOCTYPE html>
<html>
<head>
  <!-- Site made with Mobirise Website Builder v4.1.2, https://mobirise.com -->
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="generator" content="Mobirise v4.1.2, mobirise.com">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="shortcut icon" href="assets/images/logo.jpeg" type="image/x-icon">
  <meta name="description" content="">
  <title>Home</title>
  <link rel="stylesheet" href="assets/web/assets/mobirise-icons/mobirise-icons.css">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Rubik:300,300i,400,400i,500,500i,700,700i,900,900i">
  <link rel="stylesheet" href="assets/tether/tether.min.css">
  <link rel="stylesheet" href="assets/soundcloud-plugin/style.css">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="assets/dropdown/css/style.css">
  <link rel="stylesheet" href="assets/animate.css/animate.min.css">
  <link rel="stylesheet" href="assets/socicon/css/styles.css">
  <link rel="stylesheet" href="assets/theme/css/style.css">
  <link rel="stylesheet" href="assets/mobirise-gallery/style.css">
  <link href="https://fonts.googleapis.com/css?family=Rubik:300,300i,400,400i,500,500i,700,700i,900,900i" rel="stylesheet">
  <link href="assets/fonts/style.css" rel="stylesheet">
  <link rel="stylesheet" href="assets/mobirise/css/mbr-additional.css" type="text/css">
  
  
  
</head>
<body>
    <!--Project name and login/signu button-->
<section class="menu cid-rwkmCsy6gl" once="menu" id="menu1-g" data-rv-view="69">

    

    <nav class="navbar navbar-dropdown align-items-center navbar-fixed-top navbar-toggleable-sm">
        <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <div class="hamburger">
                <span></span>
                <span></span>
                <span></span>
                <span></span>
            </div>
        </button>
        <div class="menu-logo">
            <div class="navbar-brand">
                <span class="navbar-caption-wrap">

                    <h1 style="color: white; font-style: roboto; font-weight: bold; font-size:40px;">
                        Advisory and Mentoring System</h1></span>
            </div>
        </div>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
           
            <div class="navbar-buttons mbr-section-btn">


                <a class="btn btn-sm btn-primary display-4" href="login.php">
                Advisory Board</span></a>
                <a class="btn btn-sm btn-primary display-4" href="mentoring/">
                  Mentoring Git</span></a>


                </div>
        </div>
    </nav>
</section>

 <!--Carousel definition of project details-->
<section class="carousel slide cid-rwkpdQKAVW" data-interval="false" id="slider1-k" data-rv-view="71">

    

    <div class="full-screen">
        <div class="mbr-slider slide carousel" data-pause="true" data-keyboard="false" data-ride="carousel" data-interval="4000">
            <div class="container">
                <div class="carousel-inner" role="listbox">
                    <div class="carousel-item slider-fullscreen-image" data-bg-video-slide="false" style="background-image: url(assets/images/1.png);"><div class="container container-slide"><div class="image_wrapper"><div class="mbr-overlay" style="opacity: 0.6;"></div><img src="assets/images/1.jpg"><div class="carousel-caption"><div class="col-10 offset-1 align-right"><h2 class="mbr-fonts-style display-1"></h2><p class="lead mbr-text mbr-fonts-style display-5"></p></div></div></div></div></div>

                    <div class="carousel-item slider-fullscreen-image active" data-bg-video-slide="false" style="background-image: url(assets/images/2.jpg);"><div class="container container-slide"><div class="image_wrapper"><div class="mbr-overlay"></div><img src="assets/images/2.jpg"><div class="carousel-caption"><div class="col-10 offset-1 align-left"><h2 class="mbr-fonts-style display-1"></h2><p class="lead mbr-text mbr-fonts-style display-5"></p></div></div></div></div></div>

                    <div class="carousel-item slider-fullscreen-image" data-bg-video-slide="false" style="background-image: url(assets/images/3.jpg);">
                    <div class="container container-slide">
                    <div class="image_wrapper">
                    <div class="mbr-overlay">
                    </div><img src="assets/images/3.jpg"><div class="carousel-caption"><div class="col-10 offset-1 align-right"><h2 class="mbr-fonts-style display-1"></h2><p class="lead mbr-text mbr-fonts-style display-5"></p></div></div></div></div></div>

                     <!--carousel buttons, prev and next-->
                </div><a data-app-prevent-settings="" class="carousel-control carousel-control-prev" role="button" data-slide="prev" href="#slider1-k"><span aria-hidden="true" class="mbri-left mbr-iconfont"></span><span class="sr-only">Previous</span></a><a data-app-prevent-settings="" class="carousel-control carousel-control-next" role="button" data-slide="next" href="#slider1-k"><span aria-hidden="true" class="mbri-right mbr-iconfont"></span><span class="sr-only">Next</span></a></div></div></div>
</section>

 <!--Footer conatining stuents details and supervisor-->
<section class="cid-rwkmCv0qRV" id="footer1-f" data-rv-view="127">

    

    

    <div class="container">
        <div class="media-container-row content text-white">
            <div class="col-12 col-md-3 mbr-fonts-style display-7">
                <h5 class="pb-3">
                    UGOEZE GERALD EBUKA
                </h5>
                <p class="mbr-text">
                    20141929855
                    <br>Project Member
                </p>
            </div>
            <div class="col-12 col-md-3 mbr-fonts-style display-7">
                <h5 class="pb-3">
                    UWABUNKEONYE CHIDERA MAGNUS
                </h5>
                 <p class="mbr-text">
                    20141897665
                    <br>Project Member
                </p>
            </div>
            <div class="col-12 col-md-3 mbr-fonts-style display-7">
                <h5 class="pb-3">
                    UKWUOMA PRINCE CHINONSO
                </h5>
                 <p class="mbr-text">
                    20141929875
                    <br>Project Member
                </p>
            </div>
           <div class="col-12 col-md-3 mbr-fonts-style display-7">
                <h5 class="pb-3">
                    UMELO EKENE CHRISTOPHER
                </h5>
                <p class="mbr-text">
                    20141993935
                    <br>Project Member
                </p>
            </div>
        </div>
        <div class="footer-lower">
            <div class="media-container-row">
                <div class="col-sm-12">
                    <hr>
                </div>
            </div>
            <div class="media-container-row mbr-white">
                <div class="col-sm-4 copyright">
                    <p class="mbr-text mbr-fonts-style display-7" style="text-align: center;">
                        <span style="font-weight: bold;">Mrs. Odirichukwu J. C. (Supervisor)</span><br>
                     <span style="font-size: 12px;">   Department of Computer Science<br>
                      Federal University of Technology Owerri.</span>
                   
                    </p>
                </div>
                
        </div>
    </div>
</section>


  <script src="assets/web/assets/jquery/jquery.min.js"></script>
  <script src="assets/tether/tether.min.js"></script>
  <script src="assets/bootstrap/js/bootstrap.min.js"></script>
  <script src="assets/smooth-scroll/smooth-scroll.js"></script>
  <script src="assets/dropdown/js/script.min.js"></script>
  <script src="assets/touch-swipe/jquery.touch-swipe.min.js"></script>
  <script src="assets/jquery-mb-ytplayer/jquery.mb.ytplayer.min.js"></script>
  <script src="assets/jquery-mb-vimeo_player/jquery.mb.vimeo_player.js"></script>
  <script src="assets/masonry/masonry.pkgd.min.js"></script>
  <script src="assets/imagesloaded/imagesloaded.pkgd.min.js"></script>
  <script src="assets/bootstrap-carousel-swipe/bootstrap-carousel-swipe.js"></script>
  <script src="assets/viewport-checker/jquery.viewportchecker.js"></script>
  <script src="assets/theme/js/script.js"></script>
  <script src="assets/mobirise-slider-video/script.js"></script>
  <script src="assets/mobirise-gallery/player.min.js"></script>
  <script src="assets/mobirise-gallery/script.js"></script>
  <script src="assets/formoid/formoid.min.js"></script>
  
  
 <div id="scrollToTop" class="scrollToTop mbr-arrow-up"><a style="text-align: center;"><i class="mbri-down mbr-iconfont"></i></a></div>
    <input name="animation" type="hidden">
  </body>
</html>