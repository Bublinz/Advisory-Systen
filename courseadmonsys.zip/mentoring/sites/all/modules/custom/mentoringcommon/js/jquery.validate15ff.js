(function ($) { 

$(document).ready(function(){
	var getUrl = document.location.origin;
	var matchurl = getUrl+'/mentor/signup';
	var url = window.location.href;
	var full_matchin = url.split('?')[0];	
	if(matchurl == full_matchin){ 
    $('#register-box').css('display','block'); $('#hideTheDiv').css('display','block');//$("#pre-header, .region, .content").css('pointer-events','none');
	$("#edit-usertype-mentor").attr('checked','checked');$(".form-item-usertype").hide();

	}
	
	$('#name').keydown(function (e) {
		if (e.ctrlKey || e.altKey) {
		e.preventDefault();
		} else {
		var key = e.keyCode;
		if (!((key == 8) || (key == 9) || (key == 32) || (key == 46) || (key >= 35 && key <= 40) || (key >= 65 && key <= 90))) {
		e.preventDefault();
		}
		}
	});
	
	
	$(".mentor-submint-btn").click(function(){ 
	            $(".mentoringcommon-sign-up-form").attr('action','abc/sdasd');
				var name = $("#name").val();
				var email = $("#email").val();
				var file = $("#filename").val();
				var captcha = $(".g-recaptcha").val();
				var url = "sites/all/modules/custom/mentoringcommon/mentorresume.php";
				var extension = file.substr((file.lastIndexOf('.') +1));
				
				
				if(name ==""){
				   $("#name_msg").remove();
				   $("#name").after("<div id='name_msg' style='color:red'>This field is required.</div>");
                   return false;				   
				}else{					
				   $("#name_msg").remove();
				}
				if(email ==""){
					$("#emal_msg").remove();
				    $("#email").after("<div id='emal_msg' style='color:red'>This field is required.</div>");
                    return false;					
				} else {
					$("#emal_msg").remove();
				}
					
				if( !validateEmail(email)) {
					$("#emal_msg1").remove();
						$("#email").after("<div id='emal_msg1' style='color:red'>Must be valid email. example@yourdomain.com</div>"); 
						return false;						
					}else{
					$("#emal_msg1").remove();
					}					
				 if(email){ 
				 $.ajax({
				    type: "GET",
				    url: "mentoresume/emailpower",//Drupal.settings.mentoringcommon.ajaxUrl,
				    data: {email: email},
                    async: false,				   // serializes the form's elements.
				    success: function(data){
						// console.log(data);
					   if(data == "matched"){
						   $("#emal_msg2").remove(); 
						  $("#email").after("<div id='emal_msg2' style='color:red'>Email already exists, please try another.</div>"); 
						  return false; 
					   }
						if(data == "non_matched"){
						
							$("#emal_msg2").remove();   
						   
					   } // show response from the php script.
					}
				 });
				 }
				
				if(file ==""){
				$("#file_msg").remove();
				$("#filename").after("<div id='file_msg' style='color:red'>This field is required.</div>");
				return false;
				}else{
					$("#file_msg").remove();
					
				}
				if (!/(pdf|docx|doc|rtf|txt|csv)$/ig.test(extension)) {
						  $("#filename").after("<div id='file_msg2' style='color:red'>Must be pdf,doc,docx,rtf,txt and csv file.</div>");
						//alert("Invalid file type: "+extension+".  Please use DOC, PDF or Zip.");
						  $("#filename").val("");
						  return false;
					  }
                       //$("#file").after("<div id='file_msg'>only doc or pdf file allowes</div>");
                    
				else{	
				 $("#file_msg2").remove();
							
				}
				var response = grecaptcha.getResponse();
				if(response.length == 0){ 
				$("#captcha_msg").remove();
				$(".g-recaptcha").after("<div id='captcha_msg' style='color:red'>This field is required.</div>");
				return false;
				}
				
				else{
					
					$("#captcha_msg").remove();
				}
				if($("#emal_msg2").length == 0) {
                  return true
                }
				return false;
				//return false;
				//alert("ok");
				//console.log(url);
				/*$.ajax({
				   type: "GET",
				   username: 'admin',
                   password: 'Classic#$236',
				   url: "mentoringcommon/mentoresume",//Drupal.settings.mentoringcommon.ajaxUrl,
				   data: {name: name,email:email, file:file},
                   async: false,				   // serializes the form's elements.
				   success: function(data){
					   alert(data); // show response from the php script.
				   }
				 });*/
				
				
				
			});
			
			
			 function validateEmail($email) {
			  var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
			  return emailReg.test( $email );
			}
			$('#edit-searchmail').click(function(e){
				e.preventDefault();
				$("#emailresult").text('');
				var fname = $("#edit-fname").val();
				var lname = $("#edit-lname").val();
				if(fname ==''){ $("#emailresult").html("<div class='messages error'>The First Name is required.</div>"); return false;}
				if(lname ==''){ $("#emailresult").html("<div class='messages error'>The Last Name is required.</div>"); return false;}
				if(fname.length < 2){
					
					$("#emailresult").html("<div class='messages error'>The First Name should have at least 2 characters.</div>"); return false;
				}
				if(lname.length < 2){
					
					$("#emailresult").html("<div class='messages error'>The Last Name should have at least 2 characters.</div>"); return false;
				}
				
				
				$.ajax({
				    type: "GET",
				    url: "/mentoringcommon/retrievemails",//Drupal.settings.mentoringcommon.ajaxUrl,
				    data: {fname: fname,lname: lname},
                    async: false,				   // serializes the form's elements.
				    success: function(data){
						console.log(data);
						$("#emailresult").text('');
						if(data !=''){	
                        if(data == '<table></table>'){							
						   $("#emailresult").html("<div class='messages error'>Email does not exist for this name.</div>");
							
						}else{ 						
					    $("#emailresult").html("<div class='messages status'>Found the following records: " + data +"</div>");
						}
						}else{
							$("#emailresult").html("<div class='messages error'>There is no email id associated with this first name and last name.</div>");
							
						}
					}
				 });
				
				
			});
			
			
	
})
  // Original JavaScript code.
})(jQuery);