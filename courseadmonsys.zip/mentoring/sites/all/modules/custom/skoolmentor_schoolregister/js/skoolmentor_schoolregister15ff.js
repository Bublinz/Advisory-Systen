(function ($) { 
   
   
   
	$(document).ready(function(){  
    $('.submit_field_of_study').click(function(){
	if($('#edit-fostudy').val()	!=''){
	if(confirm("Are you sure you want to add Major?")){

	
			}
			else{
				return false;
			}
	 }
		
	});	
	
	$('.submit_field_of_spec').click(function(){
		
		var fostudy = $('#edit-fostudy').val();
		var fospec = $('#edit-fospec').val();
	if(fostudy !='' && fospec !=''){
	if(confirm("Are you sure you want to add Specialization?")){

	
			}
			else{
				return false;
			}
	 }
		
	});
	
	$('#user_details tr').each(function() {
       if ($(this).find('td:empty').length) $(this).remove();
    })
			
	});

})(jQuery);