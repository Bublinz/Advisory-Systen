<?php
 require_once 'php/controller.php';
?>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" version="XHTML+RDFa 1.0" dir="ltr"
  xmlns:content="http://purl.org/rss/1.0/modules/content/"
  xmlns:dc="http://purl.org/dc/terms/"
  xmlns:foaf="http://xmlns.com/foaf/0.1/"
  xmlns:og="http://ogp.me/ns#"
  xmlns:rdfs="http://www.w3.org/2000/01/rdf-schema#"
  xmlns:sioc="http://rdfs.org/sioc/ns#"
  xmlns:sioct="http://rdfs.org/sioc/types#"
  xmlns:skos="http://www.w3.org/2004/02/skos/core#"
  xmlns:xsd="http://www.w3.org/2001/XMLSchema#">


<!-- Mirrored from www.skoolmentor.com/howitworks by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 04 Nov 2019 10:33:31 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=utf-8" /><!-- /Added by HTTrack -->
<head profile="http://www.w3.org/1999/xhtml/vocab">
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
<!-- <link rel="shortcut icon" href="sites/default/files/favicon.ico" type="image/vnd.microsoft.icon" /> -->
<meta name="description" content="For Mentors" />
<meta name="generator" content="Drupal 7 (https://www.drupal.org)" />
<link rel="canonical" href="howitworks.html" />
<link rel="shortlink" href="node/4972.html" />
  <title>How It Works |  Mentoring Git</title>
   
  
  <style type="text/css" media="all">
@import url("https://www.skoolmentor.com/modules/system/system.base.css?q08noi");
@import url("https://www.skoolmentor.com/modules/system/system.menus.css?q08noi");
@import url("https://www.skoolmentor.com/modules/system/system.messages.css?q08noi");
@import url("https://www.skoolmentor.com/modules/system/system.theme.css?q08noi");
</style>
<style type="text/css" media="screen">
@import url("sites/all/modules/contrib/qtip/library/jquery.qtip15ff.css?q08noi");
@import url("sites/all/modules/contrib/qtip/css/qtip15ff.css?q08noi");
</style>
<style type="text/css" media="all">
@import url("https://www.skoolmentor.com/modules/comment/comment.css?q08noi");
@import url("sites/all/modules/contrib/date/date_api/date15ff.css?q08noi");
@import url("sites/all/modules/contrib/date/date_popup/themes/datepicker.1.715ff.css?q08noi");
@import url("https://www.skoolmentor.com/modules/field/theme/field.css?q08noi");
</style>
<style type="text/css" media="screen">
@import url("sites/all/modules/contrib/invite/modules/invite_by_email/css/invite_by_email15ff.css?q08noi");
</style>
<style type="text/css" media="all">
@import url("https://www.skoolmentor.com/modules/node/node.css?q08noi");
@import url("https://www.skoolmentor.com/modules/search/search.css?q08noi");
@import url("sites/all/modules/contrib/ubercart/uc_order/uc_order15ff.css?q08noi");
@import url("sites/all/modules/contrib/ubercart/uc_product/uc_product15ff.css?q08noi");
@import url("sites/all/modules/contrib/ubercart/uc_store/uc_store15ff.css?q08noi");
@import url("sites/all/modules/contrib/views/css/views15ff.css?q08noi");
</style>
<style type="text/css" media="all">
@import url("sites/all/modules/contrib/colorbox/styles/default/colorbox_style15ff.css?q08noi");
@import url("sites/all/modules/contrib/ctools/css/ctools15ff.css?q08noi");
@import url("sites/all/modules/contrib/hybridauth/plugins/icon_pack/hybridauth_32/hybridauth_3215ff.css?q08noi");
@import url("sites/all/modules/contrib/hybridauth/css/hybridauth15ff.css?q08noi");
@import url("sites/all/modules/contrib/hybridauth/css/hybridauth.modal15ff.css?q08noi");
</style>
<link type="text/css" rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans:400,400i,600,600i,700" media="all" />
<style type="text/css" media="all">
@import url("sites/all/modules/contrib/feedback_simple/feedback_simple15ff.css?q08noi");
@import url("sites/all/libraries/superfish/css/superfish15ff.css?q08noi");
@import url("sites/all/libraries/superfish/css/superfish-smallscreen15ff.css?q08noi");
</style>
<style type="text/css" media="all">
@import url("sites/all/themes/skoolmentor/css/bootstrap.min15ff.css?q08noi");
@import url("sites/all/themes/skoolmentor/css/style15ff.css?q08noi");
@import url("sites/all/themes/skoolmentor/css/slick15ff.css?q08noi");
@import url("sites/all/themes/skoolmentor/css/ie15ff.css?q08noi");
@import url("sites/all/themes/skoolmentor/css/ie615ff.css?q08noi");
@import url("sites/all/themes/skoolmentor/font-awesome/css/font-awesome.min15ff.css?q08noi");
</style>
  <script type="text/javascript" src="sites/all/modules/contrib/jquery_update/replace/jquery/1.10/jquery.min468f.js?v=1.10.2"></script>
<script type="text/javascript" src="https://www.skoolmentor.com/misc/jquery.once.js?v=1.2"></script>
<script type="text/javascript" src="https://www.skoolmentor.com/misc/drupal.js?q08noi"></script>
<script type="text/javascript" src="sites/all/modules/contrib/qtip/library/jquery.qtipa6f1.js?v=2.0.0pre"></script>
<script type="text/javascript" src="sites/all/modules/contrib/qtip/js/qtipa6f1.js?v=2.0.0pre"></script>
<script type="text/javascript" src="sites/all/modules/contrib/jquery_update/replace/ui/external/jquery.cookie1683.js?v=67fb34f6a866c40d0570"></script>
<script type="text/javascript" src="sites/all/modules/contrib/jquery_update/replace/misc/jquery.form.min97e5.js?v=2.69"></script>
<script type="text/javascript" src="https://www.skoolmentor.com/misc/ajax.js?v=7.59"></script>
<script type="text/javascript" src="sites/all/modules/contrib/jquery_update/js/jquery_update241d.js?v=0.0.1"></script>
<script type="text/javascript" src="sites/all/modules/admin_menu/admin_devel/admin_devel15ff.js?q08noi"></script>
<script type="text/javascript" src="sites/all/modules/custom/skoolmentor_schoolregister/js/skoolmentor_schoolregister15ff.js?q08noi"></script>
<script type="text/javascript" src="sites/all/modules/contrib/colorbox/js/colorbox15ff.js?q08noi"></script>
<script type="text/javascript" src="sites/all/modules/contrib/colorbox/styles/default/colorbox_style15ff.js?q08noi"></script>
<script type="text/javascript" src="sites/all/modules/contrib/google_analytics/googleanalytics15ff.js?q08noi"></script>
<script type="text/javascript">
<!--//--><![CDATA[//><!--
(function(i,s,o,g,r,a,m){i["GoogleAnalyticsObject"]=r;i[r]=i[r]||function(){(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)})(window,document,"script","../www.google-analytics.com/analytics.js","ga");ga("create", "UA-96598213-1", {"cookieDomain":"auto"});ga("set", "anonymizeIp", true);ga("send", "pageview");
//--><!]]>
</script>
<script type="text/javascript" src="sites/all/modules/custom/mentoringcommon/js/custom-file-input15ff.html?q08noi"></script>
<script type="text/javascript" src="sites/all/modules/custom/mentoringcommon/js/jquery.validate15ff.js?q08noi"></script>
<script type="text/javascript" src="../www.google.com/recaptcha/api.js"></script>
<script type="text/javascript" src="https://www.skoolmentor.com/misc/progress.js?v=7.59"></script>
<script type="text/javascript" src="sites/all/modules/contrib/hybridauth/js/hybridauth.modal15ff.js?q08noi"></script>
<script type="text/javascript" src="https://www.skoolmentor.com/misc/autocomplete.js?v=7.59"></script>
<script type="text/javascript" src="sites/all/modules/contrib/hybridauth/js/hybridauth.onclick15ff.js?q08noi"></script>
<script type="text/javascript" src="sites/all/libraries/superfish/jquery.hoverIntent.minified15ff.js?q08noi"></script>
<script type="text/javascript" src="sites/all/libraries/superfish/sftouchscreen15ff.js?q08noi"></script>
<script type="text/javascript" src="sites/all/libraries/superfish/sfsmallscreen15ff.js?q08noi"></script>
<script type="text/javascript" src="sites/all/libraries/superfish/supposition15ff.js?q08noi"></script>
<script type="text/javascript" src="sites/all/libraries/superfish/superfish15ff.js?q08noi"></script>
<script type="text/javascript" src="sites/all/libraries/superfish/supersubs15ff.js?q08noi"></script>
<script type="text/javascript" src="sites/all/modules/contrib/superfish/superfish15ff.js?q08noi"></script>
<script type="text/javascript" src="sites/all/themes/skoolmentor/js/bootstrap.min15ff.js?q08noi"></script>
<script type="text/javascript" src="sites/all/themes/skoolmentor/js/slick.min15ff.js?q08noi"></script>
<script type="text/javascript" src="sites/all/themes/skoolmentor/js/html5lightbox15ff.js?q08noi"></script>
<script type="text/javascript" src="sites/all/themes/skoolmentor/js/jquery.smooth-scroll15ff.js?q08noi"></script>
<script type="text/javascript">
<!--//--><![CDATA[//><!--
jQuery.extend(Drupal.settings, {"basePath":"\/","pathPrefix":"","ajaxPageState":{"theme":"skoolmentor","theme_token":"A_F_DuGuBjseI4UFJMPqtKudvByDF8itn-L2ywEpV7A","jquery_version":"1.10","js":{"sites\/all\/modules\/contrib\/jquery_update\/replace\/jquery\/1.10\/jquery.min.js":1,"misc\/jquery.once.js":1,"misc\/drupal.js":1,"sites\/all\/modules\/contrib\/qtip\/library\/jquery.qtip.js":1,"sites\/all\/modules\/contrib\/qtip\/js\/qtip.js":1,"sites\/all\/modules\/contrib\/jquery_update\/replace\/ui\/external\/jquery.cookie.js":1,"sites\/all\/modules\/contrib\/jquery_update\/replace\/misc\/jquery.form.min.js":1,"misc\/ajax.js":1,"sites\/all\/modules\/contrib\/jquery_update\/js\/jquery_update.js":1,"sites\/all\/modules\/admin_menu\/admin_devel\/admin_devel.js":1,"sites\/all\/modules\/custom\/skoolmentor_schoolregister\/js\/skoolmentor_schoolregister.js":1,"sites\/all\/modules\/contrib\/colorbox\/js\/colorbox.js":1,"sites\/all\/modules\/contrib\/colorbox\/styles\/default\/colorbox_style.js":1,"sites\/all\/modules\/contrib\/google_analytics\/googleanalytics.js":1,"0":1,"sites\/all\/modules\/custom\/mentoringcommon\/js\/custom-file-input.js":1,"sites\/all\/modules\/custom\/mentoringcommon\/js\/jquery.validate.js":1,"https:\/\/www.google.com\/recaptcha\/api.js":1,"misc\/progress.js":1,"sites\/all\/modules\/contrib\/hybridauth\/js\/hybridauth.modal.js":1,"misc\/autocomplete.js":1,"sites\/all\/modules\/contrib\/hybridauth\/js\/hybridauth.onclick.js":1,"sites\/all\/libraries\/superfish\/jquery.hoverIntent.minified.js":1,"sites\/all\/libraries\/superfish\/sftouchscreen.js":1,"sites\/all\/libraries\/superfish\/sfsmallscreen.js":1,"sites\/all\/libraries\/superfish\/supposition.js":1,"sites\/all\/libraries\/superfish\/superfish.js":1,"sites\/all\/libraries\/superfish\/supersubs.js":1,"sites\/all\/modules\/contrib\/superfish\/superfish.js":1,"sites\/all\/themes\/skoolmentor\/js\/bootstrap.min.js":1,"sites\/all\/themes\/skoolmentor\/js\/slick.min.js":1,"sites\/all\/themes\/skoolmentor\/js\/html5lightbox.js":1,"sites\/all\/themes\/skoolmentor\/js\/jquery.smooth-scroll.js":1},"css":{"modules\/system\/system.base.css":1,"modules\/system\/system.menus.css":1,"modules\/system\/system.messages.css":1,"modules\/system\/system.theme.css":1,"sites\/all\/modules\/contrib\/qtip\/library\/jquery.qtip.css":1,"sites\/all\/modules\/contrib\/qtip\/css\/qtip.css":1,"modules\/comment\/comment.css":1,"sites\/all\/modules\/contrib\/date\/date_api\/date.css":1,"sites\/all\/modules\/contrib\/date\/date_popup\/themes\/datepicker.1.7.css":1,"modules\/field\/theme\/field.css":1,"sites\/all\/modules\/contrib\/invite\/modules\/invite_by_email\/css\/invite_by_email.css":1,"modules\/node\/node.css":1,"modules\/search\/search.css":1,"sites\/all\/modules\/contrib\/ubercart\/uc_order\/uc_order.css":1,"sites\/all\/modules\/contrib\/ubercart\/uc_product\/uc_product.css":1,"sites\/all\/modules\/contrib\/ubercart\/uc_store\/uc_store.css":1,"sites\/all\/modules\/contrib\/views\/css\/views.css":1,"sites\/all\/modules\/contrib\/colorbox\/styles\/default\/colorbox_style.css":1,"sites\/all\/modules\/contrib\/ctools\/css\/ctools.css":1,"sites\/all\/modules\/contrib\/hybridauth\/plugins\/icon_pack\/hybridauth_32\/hybridauth_32.css":1,"sites\/all\/modules\/contrib\/hybridauth\/css\/hybridauth.css":1,"sites\/all\/modules\/contrib\/hybridauth\/css\/hybridauth.modal.css":1,"https:\/\/fonts.googleapis.com\/css?family=Open+Sans:400,400i,600,600i,700":1,"sites\/all\/modules\/contrib\/feedback_simple\/feedback_simple.css":1,"sites\/all\/libraries\/superfish\/css\/superfish.css":1,"sites\/all\/libraries\/superfish\/css\/superfish-smallscreen.css":1,"sites\/all\/themes\/skoolmentor\/css\/bootstrap.min.css":1,"sites\/all\/themes\/skoolmentor\/css\/style.css":1,"sites\/all\/themes\/skoolmentor\/css\/slick.css":1,"sites\/all\/themes\/skoolmentor\/css\/ie.css":1,"sites\/all\/themes\/skoolmentor\/css\/ie6.css":1,"sites\/all\/themes\/skoolmentor\/font-awesome\/css\/font-awesome.min.css":1}},"colorbox":{"opacity":"0.85","current":"{current} of {total}","previous":"\u00ab Prev","next":"Next \u00bb","close":"Close","maxWidth":"98%","maxHeight":"98%","fixed":true,"mobiledetect":true,"mobiledevicewidth":"480px"},"qtip":{"target_position":"bottom_center","tooltip_position":"top_center","show_speech_bubble_tip":1,"show_speech_bubble_tip_side":1,"speech_bubble_size":"12","show_speech_bubble_tip_solid":0,"show_shadow":0,"rounded_corners":1,"color":"ui-tooltip-jtools","custom_color":"","show_event_type":"mouseenter","hide_event_type":"mouseleave","show_webform_descriptions":0,"additional_elements":""},"googleanalytics":{"trackOutbound":1,"trackMailto":1,"trackDownload":1,"trackDownloadExtensions":"7z|aac|arc|arj|asf|asx|avi|bin|csv|doc(x|m)?|dot(x|m)?|exe|flv|gif|gz|gzip|hqx|jar|jpe?g|js|mp(2|3|4|e?g)|mov(ie)?|msi|msp|pdf|phps|png|ppt(x|m)?|pot(x|m)?|pps(x|m)?|ppam|sld(x|m)?|thmx|qtm?|ra(m|r)?|sea|sit|tar|tgz|torrent|txt|wav|wma|wmv|wpd|xls(x|m|b)?|xlt(x|m)|xlam|xml|z|zip","trackColorbox":1},"urlIsAjaxTrusted":{"\/howitworks":true,"\/system\/ajax":true},"superfish":{"1":{"id":"1","sf":{"animation":{"opacity":"show","height":"show"},"speed":"fast"},"plugins":{"touchscreen":{"behaviour":"1","mode":"window_width","breakpointUnit":"px"},"smallscreen":{"mode":"window_width","breakpoint":320,"breakpointUnit":"px","title":"Main menu"},"supposition":true,"supersubs":true}}},"ajax":{"edit-usertype-mentee":{"event":"change","callback":"signup_type_ajax_callback","progress":{"message":""},"wrapper":"signup_type_dropdown_replace","url":"\/system\/ajax","submit":{"_triggering_element_name":"usertype"}},"edit-usertype-mentor":{"event":"change","callback":"signup_type_ajax_callback","progress":{"message":""},"wrapper":"signup_type_dropdown_replace","url":"\/system\/ajax","submit":{"_triggering_element_name":"usertype"}}}});
//--><!]]>
</script>
  
 
		
	

		
	

</head>
<body>
    <header id="about" style="background: url('sites/default/files/styles/banner_images/public/pictures/skoolmentor_1_1535461556.jpg')" >
<div class="navbar-wrap">
	<div class="container">
	<nav class="navbar navbar-default main-menu" >
		    <div class="navbar-header">
		    	<div class="mob-menu-bg">
		        <button type="button" data-target="#navbarCollapse" data-toggle="collapse" class="navbar-toggle">
		            <span class="sr-only">Toggle navigation</span>
		            <span class="icon-bar"></span>
		            <span class="icon-bar"></span>
		            <span class="icon-bar"></span>
		        </button>
		        <!--<ul class="btn-mob">
		        	<li class="btn-signin"><a href="#">Sign in</a></li>
		        	<li class="btn-signin"><a href="#" >Register</a></li>
		        </ul>-->
		    	</div>
				 				  <a href="index.php" title="Home" rel="home" id="logo" class="navbar-brand">
					<h2 style="color:white;">Mentoring Git</h2>
				  </a>
						        
			
		    </div>
		    <div id="navbarCollapse" class="collapse navbar-collapse">
					  <div class="region region-header">
    <div id="block-superfish-1" class="block block-superfish">

   
  
  <div class="content">
    <ul  id="superfish-1" class="menu sf-menu sf-main-menu sf-horizontal sf-style-none sf-total-items-7 sf-parent-items-2 sf-single-items-5 nav navbar-nav"><li id="menu-2600-1" class="first odd sf-item-1 sf-depth-1 sf-total-children-4 sf-parent-children-0 sf-single-children-4 menuparent"><a href="index.php" title="" class="sf-depth-1 menuparent nolink">Home</a></li><li id="menu-2249-1" class="middle even sf-item-2 sf-depth-1 sf-no-children"><a href="testimonials.php" title="" class="sf-depth-1">Success Stories</a></li><li id="menu-218-1" class="middle odd sf-item-3 sf-depth-1 sf-no-children"><a href="howitworks.php" class="sf-depth-1">How It Works</a></li><li id="menu-334-1" class="middle odd sf-item-5 sf-depth-1 sf-no-children"><a href="../index.php" title="" class="sf-depth-1"> Main Page</a></li><li id="menu-1146-1" class="middle even sf-item-6 sf-depth-1 sf-no-children"><a href="javascript:void(0)" title="" class="sf-depth-1 nolink">Sign-in</a></li><li id="menu-2602-1" class="last odd sf-item-7 sf-depth-1 sf-no-children"><a href="javascript:void(0)" title="" class="sf-depth-1 nolink">Register</a></li></ul>  </div>
</div>
  </div>


					

		    </div>
		</nav>
				<div id="login-box" class="signin-menu" style="display: none; padding-left: 10px; border-radius: 0px">
						<!-- <a href="#" class="close"><img src="sites/all/themes/simplecorp/images/close_pop.png" class="btn_close" title="Close Window" alt="Close" /></a>
						-->
						<div class="hidden-lg"><a href="#" class="close"><img src="sites/all/themes/skoolmentor/images/close_pop.png" class="btn_close" title="Close Window" alt="Close"></a></div>
						<h3 style="display:block;text-align:center; margin: 0;padding: 10px 0 20px;font-size: 18px;font-weight:bold; border-bottom: 1px solid #EDEEEF;">Login to SkoolMentor</h3>
						<div style="/*display:inline-block; margin-left:30px*/">
							
							<form  method="post"  accept-charset="UTF-8"><div><div class="form-item form-type-textfield form-item-name">
  <label for="edit-name">Username <span class="form-required" title="This field is required.">*</span></label>
 <input type="text" id="edit-name" name="username" value="" size="27" maxlength="60" class="form-text required" />
</div>
<div class="form-item form-type-password form-item-pass">
  <label for="edit-pass">Password <span class="form-required" title="This field is required.">*</span></label>
 <input type="password" id="edit-pass" name="pass" size="27" maxlength="128" class="form-text required" />
</div>
 <div class="form-group terms-conditions text-center">
                <input type="checkbox" id="register-agree" name="mentor"  value="1"  class="form-control-custom">
                <label for="register-agree">I am a Mentor</label>
              </div>
<div class="form-actions form-wrapper" id="edit-actions"><input type="submit"  name="menlogin" value="Log In" class="form-submit" /></div></div></form>

<a href=" " style = "font-size: 15px;color: #878787;display: block;text-align: center; font-size: 15px;">Forgot Username ?</a>
							<a href=" " style = "font-size: 15px;color: #878787;display: block;text-align: center; font-size: 15px;">Forgot Email ?</a>
						<a href=" " style = "font-size: 15px;color: #878787;display: block;text-align: center; font-size: 15px;">Forgot Password ?</a>		
					</div>
					
					<div style="display:inline-block; min-width: 100%;">	
						 
								</div>
								
							</div>	
	</div></div>
	
<div class="container"> 

		
		<!--------------------------  Sign up Form content start here ---------------------------->

<div id="content">


							<div id="register-box" class="register-popup" >
						<a href="#" class="close"><img src="sites/all/themes/skoolmentor/images/close_pop.png" class="btn_close" title="Close Window" alt="Close" /></a>
						<form action="https://www.skoolmentor.com/howitworks" method="post" id="mentoringcommon-sign-up-form" accept-charset="UTF-8"><div><h3 id="popheader" style="display:block;text-align:center; margin-botton: 15px; border-bottom: 1px solid #EDEEEF;">Create A New Profile</h3>
	
	<div style="display:block; ">
	<div style="display:block;text-align: center;"><div style = "width:100%; float:left;   padding: 0% 0%;" ><div >
 
 <div >
	<div style = "width: 100%; float:left;   padding: 0 0 5% 0;" ><a href="mentee/register.php">As a Mentee </a></div></div>

<div style = "width: 100%; float:left;   padding: 0 0 5% 0;" ><a href="mentor/register.php"> As a Mentor </a></div>

</div>
</div>
<div id="signup_type_dropdown_replace"><input type="hidden" name="selected_type" />
</div></div><!----- Mentor sign up form    --><div class="mentor-content">
		<p>If you would like to apply to be a mentor, then please submit your resume. One of our representatives will get back to you shortly with the next steps.</p>
		<div class="mentor-form">
			
				<div class="form-element">
					<input placeholder="Name *" type="text" name="mentor_name" id="name">
					</div><div class="form-element">
					<input placeholder="Email Address *" type="email" name="mentor_email" id="email">
				</div>
				
				<div class="mentor-upload">
					<div class="box">
						<input type="file" name="mentor_filename" id="filename" class="filename" placeholder="File *"/>
						
					</div>
				</div>
				<div style="box-sizing: border-box;padding: 0 15px;">
				<div class="g-recaptcha" data-sitekey="6Lf7-FkUAAAAAGnreC_Y7fDr1ZkrUw5ZjmUO_QrI" data-callback="correctCaptcha"></div>
				</div>
				<div class="mentor-submint-btn">
					<input type="submit" value="Submit" class="mentor-submint-btn">
				</div>
			
		</div>
	</div> <!----- Mentor Sign up form ------><div id="hideTheDiv" ><div id="facebook-button" style = "width:100%; float:left; padding: 0;" ><input type="submit" id="edit-submit--4" name="op" value="Sign up with facebook" class="form-submit" /></div><input type="hidden" name="form_build_id" value="form-hZrsBe1ig5gj1fBvmMvEbmZr6MxWcoDGYo3PZ9vMCf8" />
<input type="hidden" name="form_id" value="mentoringcommon_sign_up_form" />
<div class="separator" style="display:inline-block;margin-left: 0px !important; height: auto; width: 100	%;margin-top: 1%;">
							<div style="text-align:center;">OR</div>
					</div>
					<div style = "width:100%; float:left;   padding: 5% 0 0 0; " ><div class="hybridauth-widget-wrapper"><div class="item-list"><ul class="hybridauth-widget"><li class="first last"><a href="https://www.linkedin.com/oauth/v2/authorization?client_id=862kl9ndy74lns&amp;redirect_uri=https%3A%2F%2Fwww.skoolmentor.com%2Fhybridauth%2Fendpoint%3Fhauth.done%3DLinkedIn&amp;response_type=code&amp;scope=r_liteprofile+r_emailaddress+w_member_social&amp;state=9d0e06cec4bd6fa851b27e96e4ca5539bd0f6e384cd9df8c574d6514c972204f" title="LinkedIn" class="hybridauth-widget-provider hybridauth-onclick-current" rel="nofollow" data-hybridauth-provider="LinkedIn" data-hybridauth-url="/hybridauth/window/LinkedIn?destination=hybridauth/live&amp;destination_error=node/1" data-ajax="false" data-hybridauth-width="800" data-hybridauth-height="500"><span class="hybridauth-icon linkedin hybridauth-icon-hybridauth-32 hybridauth-linkedin hybridauth-linkedin-hybridauth-32" title="LinkedIn"><span class="element-invisible">Login with LinkedIn</span></span>
</a></li>
</ul></div></div>
</div><div class="separator" style="display:inline-block;margin-left: 0px !important; height: auto; width: 100%;margin-top: 1%;">
						<div style="text-align:center;">OR</div>
						</div>
					<div style = "width: 100%; float:left;   padding: 0 0 5% 0;" ><div class="form-actions form-wrapper" id="edit-actions--2"><input type="submit" id="edit-submit" name="op" value="Sign Up(Standard)" class="form-submit" /></div></div></div></div>
	</div><script type="text/javascript">
		
		function correctCaptcha() {
			console.log("captcha is working");
		}
		(function ($) {
			$("input[id^=edit-submit]").addClass("signupbutton");
			$("#edit-submit").css("width","100%");
			$("input[id=edit-submit--4]").addClass("facebookbutton");
			$("input[id=edit-submit--5]").addClass("linkedinbutton");
			$("#hideTheDiv").hide();
			$(".mentor-content").hide();
			$(".box label").css("display", "block");
			$("input[id^=edit-usertype]").change(function(){
				if($(this).attr("checked", true)){
					var usertype = $(this).val();
					
				
					if(usertype ==="mentor"){
						$("#mentoringcommon-sign-up-form").attr("action","mentoresume/submit.html");
						$(".uploadimage").css("display", "block !important");
						$("#edit-usertype-mentor").removeAttr("disabled");
						$("#edit-usertype-mentee").removeAttr("disabled");
						$("#hideTheDiv").hide();
						$(".mentor-content").show();
						$(".register-popup").css("max-width","640px");
						$("#popheader").text("Apply to be a Mentor");
						
						
					}else{
					$("#mentoringcommon-sign-up-form").attr("action","mentee/register.html");
					$("#edit-usertype-mentor").removeAttr("disabled");
					$("#edit-usertype-mentee").removeAttr("disabled");
					$("#hideTheDiv").show();
					$(".mentor-content").hide();					
					$("div.register-popup").css("width","");
					$("#popheader").text("Create A New Profile");
					$(".register-popup").css("max-width","400px");
					}
				}
			});
			
			
		})(jQuery);
		
	</script></div></form>					</div>
					</div>
					  <div style="clear:both"></div>
<!----------------------------------------------  Sign up form End here -------------------------------->
		
     </div>
	 <div style="clear:both"></div>
	 	
	
	  
	
	

		
</header>
<div class="breadcrumbs">
	<div class="container">
		<ul>
			<li>       <h2 class="element-invisible">You are here</h2><div class=""><span class="inline odd first"><a href="index.html">Home</a></span> <span class="delimiter">»</span> <span class="inline even last">How It Works</span></div></li>			
		</ul>
	</div>
</div>



<div class=" about-content How-It-Works">
	<div class="container">
		    
    <div id="content" class="column"><div class="section">
            <a id="main-content"></a>
            	          <h2><span style="text-transform: capitalize;">
          How It Works        </span></h2>
		                          <div class="tabs">
                  </div>
              <div class="region region-help">
    <div id="block-system-main" class="block block-system">

    
  <div class="content">
    <div id="node-4972" class="node node-page node-full clearfix" about="/howitworks" typeof="foaf:Document">

      <span property="dc:title" content="How It Works" class="rdf-meta element-hidden"></span><span property="sioc:num_replies" content="0" datatype="xsd:integer" class="rdf-meta element-hidden"></span>
  
  <div class="content clearfix">
    <div class="field field-name-body field-type-text-with-summary field-label-hidden"><div class="field-items"><div class="field-item even" property="content:encoded"> 
		 
<div id="6MuUJ8BBqLs" style="display:none;">
  <div class="lightboxcontainer">
	<div class="lightboxright">
	  <iframe width="680px" height="420px" src="https://www.youtube.com/embed/6MuUJ8BBqLs" frameborder="0" allowfullscreen=""></iframe>
	</div>
	<div style="clear:both;"></div>
</div></div>
<div id="1QjED2ITVrs" style="display:none;">
  <div class="lightboxcontainer">
	<div class="lightboxright">
	  <iframe width="680px" height="420px" src="https://www.youtube.com/embed/1QjED2ITVrs" frameborder="0" allowfullscreen=""></iframe>
	</div>
	<div style="clear:both;"></div>
</div></div>
<div class="row work-detail">
			<div class="how-it-work-tab">
		<div class="container">	
			<div class="row">
				<div class="col-sm-12">
					<ul class="nav nav-tabs"><li class="active"><a data-toggle="tab" href="#mentee">Mentor</a></li>
					  <li><a data-toggle="tab" href="#mentor">Mentee</a></li>
					</ul><div class="tab-content">
					  <div id="mentee" class="tab-pane fade in active">
					    <div class="view-content">
					    	<div class="col-sm-4 text-center">
					    		<img src="sites/all/themes/skoolmentor/images/hit-ico1.png" /><p>Create your profile and select the areas you would like to mentor.</p>
					    	</div>
					    	<div class="col-sm-4 text-center">
					    		<img src="sites/all/themes/skoolmentor/images/hit-ico2.png" /><p>Accept a connection request,search for a suitable mentee and invite a mentee.</p>
					    	</div>
					    	<div class="col-sm-4 text-center">
					    		<img src="sites/all/themes/skoolmentor/images/hit-ico3.png" /><p>Start sharing knowledge.</p>
					    	</div>
					    </div>
					  </div>
					  <div id="mentor" class="tab-pane fade">
					    <div class="view-content">
					    	<div class="col-sm-3 text-center">
					    		<img src="sites/all/themes/skoolmentor/images/hit-ico1.png" /><p>Create your profile and select the areas you would like mentoring in.</p>
					    	</div>
					    	<div class="col-sm-3 text-center">
					    		<img src="sites/all/themes/skoolmentor/images/hit-ico4.png" /><p>Search for a suitable mentor and initiate a connection request.</p>
					    	</div>
					    	<div class="col-sm-6 text-center">
					    		<img src="sites/all/themes/skoolmentor/images/hit-ico5.png" /><p>Once the mentor accepts the connection request. You and your mentor are now connected. Send messages or setup Skype sessions to get all the information and guidance you need.</p>
					    	</div>
					    </div>
					  </div>
					</div>    	    	  
				</div> 
			</div>
		</div>	
	</div>
		</div></div></div></div>  </div>

  
  
</div>
  </div>
</div>
  </div>
                  
    </div></div> <!-- /.section, /#content -->
	
	    </div><!-- Container end--->
</div><!-- about-content end--->
<footer>
	
	<div class="copyright">
		<p>  <div class="region region-footer">
    <div id="block-block-8" class="block block-block">

    
  <div class="content">
    <p>Copyright © 2019 Mentoring Git. All Rights Reserved.</p>  </div>
</div>
  </div>
</p>
	</div>
</footer>




  <script type="text/javascript">
					(function ($) {
						$('#howItWorksDiv').hide();
						$('li.sf-item-6 .sf-depth-1.nolink').attr('id','signInForSkoolMentor');
						$('li.sf-item-6 .sf-depth-1.nolink').addClass('signup_button big fill sign-button-style bbg');
						$('li.sf-item-6 .sf-depth-1.nolink').attr('href','#login-box');
                        $('li.sf-item-7 .sf-depth-1.nolink').attr('id','register_form');						
						$('li.sf-item-3 .sf-depth-1.nolink').click(function() {
							
							//Fade in the Popup and add close button
							$('#howItWorksDiv').slideToggle(100);
							if($('#login-box').is(':visible')){
								$('#login-box').slideToggle(50);
								$('#signInForSkoolMentor').toggleClass('bbg');
							}
							if($('#faqsButton').hasClass('bbg')){
								$('#faqsButton').toggleClass('bbg');
							}else if(window.location.href.indexOf("faqs") > -1 && !$('#howItWorksButton').hasClass('bbg')){
								$('#faqsButton').toggleClass('bbg');	
							}
							return false;
						});
						$("[id^='edit-submit']").each(function(){
							if($(this).attr("value") ==  "Log In"){
							 $(this).attr('style','background-color: rgb(255, 150, 14); background-image: none ! important; margin-left: 10%; width: 78%; padding: 7px 12px; font-size: medium; font-weight: bolder;');
							}
						});
					
					})(jQuery);
				</script>
<script type="text/javascript">			
var $jq = jQuery.noConflict();
	$jq(document).ready(function() {
		/*$jq('.banner-content-slider').slick({
			infinite: true,
			slidesToShow: 1,
			dots: false,
			arrows: true,
			autoplay: true,
			slidesToScroll: 1,
			responsive: [
	    {
	      breakpoint: 768,
	      settings: {
	        dots: true,
	        arrows: false
	      }
	    }
	  	]
		});*/

	    $jq('.mentor-slider').slick({
	    	infinite: false,
			slidesToShow: 4,
			dots: true,
			arrows: false,
			slidesToScroll: 4,
			responsive: [
	    {
	      breakpoint: 768,
	      settings: {
			slidesToScroll: 1,
	        slidesToShow: 1
	      }
	    }
	  	]
		});

		$jq('.testimonial-slider').slick({
	    	infinite: true,
			slidesToShow: 2,
			dots: false,
			arrows: true,
			slidesToScroll: 2,
			responsive: [
	    {
	      breakpoint: 768,
	      settings: {
	        slidesToShow: 1
	      }
	    }
	  	]
		});

	if(window.innerWidth >= 767){
	    $jq(function(){
	        var stickyHeaderTop = ($jq('#stickyheader').offset()  || { "top": NaN }).top;
	        $jq(window).scroll(function(){
                if( $jq(window).scrollTop() > stickyHeaderTop ) {
                    $jq('#stickyheader').addClass('navbar-fixed-top'); 
                } 
                else {
                    $jq('#stickyheader').removeClass('navbar-fixed-top');
                }
	        });
	  	});
	}
});
</script>
<script type="text/javascript">
					//$(document).ready(function() {
					(function ($) {
						var queryString = location.search;
			if( queryString.indexOf("keyword=") >= 0) {
							$('#keywordSearchTextBox').val(queryString.substring(queryString.indexOf("keyword=")+8).replace("%20", " "));
				$('#keywordSearchTextBox').css("color","black");
			}
			$('#howItWorksButton').bind('contextmenu', function (e) {
	                     e.preventDefault();
	                     alert('Right Click is not allowed');
	                   });
						$('a.signup_button').click(function(){
							  $(this).toggleClass("bbg");
						});

						$('#mentoringcommon-login').submit(function(){
								$(this).find(".form-submit").val("Loading....");
								$(this).prop("disable",true);
							});
						$('div.register-popup').hide();
						$('div.signin-menu').hide();
						$('#faqsButton').click(function() {
							if($('#howItWorksDiv').is(':visible')){
								$('#howItWorksDiv').slideToggle(50);
								$('#howItWorksButton').toggleClass('bbg');
							}
							if($('#login-box').is(':visible')){
								$('#login-box').slideToggle(50);
								$('#signInForSkoolMentor').toggleClass('bbg');
							}
						});
						$('#signInForSkoolMentor').click(function() {
							var userlogin = "";
							if(userlogin !=''){
								return false;
							}
							
							// Getting the variable's value from a link 
							var position =$(this).position();
							var loginBox = $(this).attr('href');
							
							if($('#howItWorksDiv').is(':visible')){
								$('#howItWorksDiv').slideToggle(50);
								$('#howItWorksButton').toggleClass('bbg');
							}
							if($('#faqsButton').hasClass('bbg')){
								$('#faqsButton').toggleClass('bbg');
							}else if(window.location.href.indexOf("faqs") > -1 && !$('#signInForSkoolMentor').hasClass('bbg')){
								$('#faqsButton').toggleClass('bbg');	
							}
						    $(loginBox).slideToggle(50);
						    $(loginBox+'> div > form > div > div > input').each(function(){
							if($(this).attr("value") ==  "Log In"){
									 $(this).attr('style','background-color: rgb(255, 150, 14); background-image: none ! important; margin-left: 10%; width: 78%; padding: 7px 12px; font-size: medium; font-weight: bolder;');
									}else{
										if(this.name == "name"){
											$(this).val("Username");
										}else if(this.name == "pass"){
											$(this).val("Password");
										}
										$(this).css("width",'73%');							
										$(this).css("border-radius",'5px');							
										$(this).css("margin",'2% 10%');							
										var valueText = this.value;
										var typeText = this.type;
									    $(this).css('color','#cdcdcd');
									    $(this).css('font-weight','bold');
									    if(typeText == "password" && this.value == "Password")
										this.type ='text';
																		
										$(this).focus(function(){
											if(typeText == "password")
											this.type ='password';
											
									        if(this.value == valueText) {
									            this.value = '';
									            $(this).css('color','black');
											    $(this).css('font-weight','normal');
											    if(this.name == "name"){
												    var password = $(this).parent().siblings(".form-type-password").children("input");
												    focused = setInterval(function() {
															if (password.val() !== "Password") {
																	password.triggerHandler( "focus" );
																clearInterval(focused);
												            }
												    }, 50);
											    }
											
											}
									    });
									
									    $(this).blur(function(){
									        if(this.value == '') {
									            this.value = valueText;
									            $(this).css('color','#cdcdcd');
											    $(this).css('font-weight','bold');
											    if(typeText == "password")
												this.type ='text';
												
											}
									    });
									}
							    });
						
							return false;
						});
						
						$('#register_form').click(function() {
							
							$('#login-box').hide();
							$('#signInForSkoolMentor').toggleClass("bbg");
							var registerBox = $('#register-box');
							
							//Fade in the Popup and add close button
							$(registerBox).fadeIn(300);
							
							//Set the center alignment padding + border
							//var popMargTop = ($(registerBox).height() + 24) / 2; 
							//var popMargLeft = ($(registerBox).width() + 24) / 2; 
							
							//$(registerBox).css({ 
								//'margin-top' : -popMargTop,
								//'margin-left' : -popMargLeft
							//});
							
							// Add the mask to body
							$('body').append('<div id="mask"></div>');
							$('#mask').fadeIn(300);
							$("label[for^=edit-usertype]").show();
							return false;
						});
						
						// When clicking on the button close or the mask layer the popup closed
						$('a.close').click(function() {
							$('#mask , .signin-menu').fadeOut(300 , function() {
								$('#mask').remove();  
							});
							$('#mask , .register-popup').fadeOut(300 , function() {
								$('#mask').remove();  
							}); 
							return false;
						});

						$("#keywordSearchTextBox").each(function(){
							if(!this.value){
								this.value = "Keyword Search";
								$(this).css("color","#ABA6A6");
							    }
						    var valueText = "Keyword Search";
							$(this).css("font-weight","bold");
							$(this).css("border","1px solid #514B4B");
							$(this).css("border-style","solid");
							$(this).keydown(function(){
						        if(this.value == valueText) {
						            this.value = "";
						            $(this).css("color","black");
								    $(this).css("font-weight","normal");
								}
						    });

						    $(this).blur(function(){
						        if(this.value == "") {
						            this.value = valueText;
						            $(this).css("color","#ABA6A6");
								    $(this).css("font-weight","bold");
								}
						    });
						    $(this).keydown(function(event){
							 if(event.which == 13){
									window.location.href = ""+$(this).attr('myattr')+""+$(this).val();
							}
						     });
						});
						$("#keywordSearchImage").each(function(){

							$(this).click(function(){
							window.location.href = ""+$("#keywordSearchTextBox").attr('myattr')+""+$("#keywordSearchTextBox").attr('value');
							});
							$(this).mouseover(function(){
								$(this).css('cursor','pointer');
							});
						});
						$(document).click(function(event) {
						if(!$(event.target).closest('#login-box').length &&
							!$(event.target).is('#login-box')) {
							if($('#login-box').is(":visible")) {
							$('#login-box').hide();
							}
						}
						});
						$(document).ready(function () {
							$("ul#resourcesDropdownContent").hide();
							$('div.action-tab-div li').mouseenter(function() {
								$('ul#resourcesDropdownContent', this).animate({opacity: 'show'}, 'slow');
							});
							$('div.action-tab-div li').mouseleave(function() {
								$('ul#resourcesDropdownContent', this).animate({opacity: 'hide'}, 'fast');
							});
						});
					//});
						//$(h1).hide();
					})(jQuery);
				</script>
<script type="text/javascript">
    var html5lightbox_options = {
		autoclose: true,
        watermark: "http://html5box.com/images/html5boxlogo.png",
        watermarklink: "http://html5box.com"
    };
</script>
<script type="text/javascript">
    var $rd = jQuery.noConflict();
	$rd(document).on('click', '#school-name li', function(){ 
	     $rd('#edit-school-name').val($rd(this).text());
		 $rd('.school_name_auto').remove();
    });
	
	$rd(document).on('click', '#college-name li', function(){ 
		 $rd('#edit-college-name').val($rd(this).text());
		 $rd('.school_name_auto').remove();
    });
	
	$rd(document).on('click', '#school-attending li', function(){ 
		 $rd('#edit-schoolattending').val($rd(this).text());
		 $rd('.school_name_auto').remove();
    });
	
	$rd(document).on('click', '#school-attending1 li', function(){ 
		 $rd('#edit-school-attending').val($rd(this).text());
		 $rd('.school_name_auto').remove();
    });  
	
	$rd(document).on('click', '#lastschool-attended li', function(){ 
		 $rd('#edit-lastschoolattended').val($rd(this).text());
		 $rd('.school_name_auto').remove();
    });

	$rd(document).on('click', '#last-school-attended li', function(){ 
		 $rd('#edit-last-school-attended').val($rd(this).text());
		 $rd('.school_name_auto').remove();
    }); 
	
	$rd(document).on('click', '#high-school li', function(){ 
		 $rd('#edit-highschoolname').val($rd(this).text());
		 $rd('.school_name_auto').remove();
    });
	
	
	
	
	
    $rd(document).ready(function () {
		var url      = window.location.href; 
		urls = url.replace(/\/[^\/]*$/, '/notifications');
		//$rd('.form-submit').click(function(e){ e.preventDefault(); alert("dsd"); alert($rd("input[name='pic[fid]']").val()); });
		$rd("#edit-payment-pending").contents().appendTo('.graph-plugin-area');
		$rd("a[href='/no-alert']").parent().addClass('no-alert');
		$rd("#menu-2614-1").addClass('welcomebuttonbell');
		$rd("a[href^='/user/password']").attr('href','/usr/password');
		//$rd("a[href='/alert']").attr('href', urls);
		$rd('ul.primary').removeClass('primary').addClass('nav nav-tabs');
		$rd('#mentoringcommon-register-form--2').attr('id','mentoringcommon-register-form');
		$rd('#mentoringcommon-login--2').attr('id','mentoringcommon-login');
		$rd('#mentee-profile-form--2').attr('id','mentee-profile-form');
		$rd('#mentor-profile-form--2').attr('id','mentor-profile-form');
		$rd('.slick-dots li').slice(5, 100).remove();
		$rd('.owl-pagination').addClass('hidden-sm hidden-md hidden-lg');
		$rd('.owl-buttons').addClass('hidden-xs');
		$rd('#edit-pass-pass1').attr('maxlength','20');
		$rd('#edit-transfer').parent().parent().removeClass('step-two-top');
		if($rd(".compose-tips").find("table.tableheader-processed").length !==0){
			$rd("table").wrap("<div class='table-responsive'></div>");
			$rd("table").addClass('table table-bordered');
			
			
		}
		$rd('.workstatustitlepro_stu').parent().addClass('mentor_type_stu_pro');
		$rd('.workstatuts_con').parent().parent().addClass('step-two-top-bg');
		$rd("label[for='edit-resume']").append('<span class="form-required" title="This field is required.">*</span>');
		$rd('.workstatustitle').parent().parent().parent().parent().addClass('mentee-bg-type');
		$rd('#edit-mentee-type-highschool').parent().parent().parent().parent().parent().parent().addClass('mentee-bg-type');
		$rd('#edit-mentee-type-highschool').parent().parent().parent().parent().parent().css('padding','10px 0');
		$rd('#edit-highschool').parent().parent().addClass('mentee-bg-type');
		$rd('#edit-highschool').parent().parent().css('padding','10px 0');
		$rd('#edit-transfer').parent().parent().css('padding','10px 0');
		$rd('.form-type-select').removeClass('form-type-select');
		$rd('#edit-filtersubmit').parent().css({'width' : '100%','display' : 'inline-block'});
		//$rd('#edit-stateusa').parent().css('border')
		$rd('.form-select').wrap('<div class="form-item form-type-select form-item-type"></div>');
		$rd('#edit-student').parent().parent().removeClass('step-two-top');
		$rd('#edit-professional').parent().parent().removeClass('step-two-top');
		$rd('#edit-mentee-type-highschool').parent().parent().wrap('<div class="studentype_boxes"></div>');
		$rd(".user_deactivate_by_skoolmentor").click(function(){
			if(confirm("Are you sure you want to deactivate this user?")){				
			}
			else{
				return false;
			}
		});
		
		/*************  Start : Tooltip click disbled **********/
		$rd("label").on("click",function(){ return false;});
		/*************  End : Tooltip click disbled **********/		
		/*************************  Watermark start ********************/
		/*var watermark = 'Start typing ...';	         
	         $rd('#edit-school-name, #edit-college-name, #edit-schoolattending, #edit-lastschoolattended, #edit-highschoolname').val(watermark).addClass('watermark');	         
				$rd('#edit-school-name, #edit-college-name, #edit-schoolattending, #edit-lastschoolattended, #edit-highschoolname').blur(function(){
					if ($rd(this).val().length == 0){
						//$rd(this).val(watermark).addClass('watermark');
					}
				});	         
				$rd('#edit-school-name, #edit-college-name, #edit-schoolattending, #edit-lastschoolattended, #edit-highschoolname').focus(function(){
					if ($rd(this).val() == watermark){
						$rd(this).val('').removeClass('watermark');
					}
				}); */
		
		/*************************  Watermark end ********************/
		
		$rd("label").each(function () {
          var originalSrc = $rd(this).attr('for');
		  var originalval = $rd.trim(originalSrc);
	if(originalval =='edit-school-name' || originalval =='edit-college-name' || originalval=='edit-highschoolname'){
			console.log('truely');
			
		    $rd(this).append("<div class='tooltip_parent'><span class='tooltips'>? 		    <div class='skoolmentor-tooltip' style='display: none;'><p>If you do not see your high school/community college name here, it implies that your high school/community college is not registered with SkoolMentor. Please send an email to support@skoolmentor.com with your full name, the full name of your high school/community college including the school's complete mailing address requesting that your school be added to our database.</p></div></span></div>");	
		}
		else if(originalval =='edit-lastschoolattended'){
		$rd(this).append("<div class='tooltip_parent'><span class='tooltips'>? 		    <div class='skoolmentor-tooltip' style='display: none;'><p>Please enter the college name of your most recent college.</p></div></span></div>");	
			
		}else if(originalval =='edit-schoolattending'){
			$rd(this).append("<div class='tooltip_parent'><span class='tooltips'>? 		    <div class='skoolmentor-tooltip' style='display: none;'><p>If you do not see your college name here, it implies that your college is not registered with SkoolMentor. Please send an email to support@skoolmentor.com with your full name, the full name of your college including the college's complete mailing address requesting that your college be added to our database</p></div></span></div>");
			
		}

		  
		});
		//console.log(document.referrer);
		$rd("select[name^=country]").click(function(e){
			var coutry = $rd(this).val();
			if(coutry =="USA"){
				
				$rd('select[name^=stateUSA]').parent().parent().css('display','block');
				$rd('select[name^=cityUSA]').parent().parent().css('display','block');
				
			}
			
		});
		
		
		/**************************  School Name Auto Populate *****************************/
		$rd("#edit-school-name").keyup(function() { 
		    var name = $rd('#edit-school-name').val();
			if (name == "") {
			   $rd('.school_name_auto').remove();	
            }else {
            $rd.ajax({
            type: "POST",
            url: "/mentoringcommon/autopopulate",
            data: {
            id: 'school-name',
			search: name
            },success: function(html) {
                 $rd('.school_name_auto').remove();
                 $rd("#edit-school-name").after(html);
            } 
		  });
 
       }
 
    });
	
	
	$rd("#edit-college-name").keyup(function() { 
		    var name = $rd('#edit-college-name').val();
			if (name == "") {
			$rd('.school_name_auto').remove();	
            }else {
            $rd.ajax({
            type: "POST",
            url: "/mentoringcommon/autopopulate",
            data: {
			id: 'college-name',
            search: name
            },success: function(html) {
                 $rd('.school_name_auto').remove();
                 $rd("#edit-college-name").after(html);
            } 
		  });
 
       }
 
    });
	$rd("#edit-schoolattending").keyup(function() { 
		    var name = $rd('#edit-schoolattending').val();
			if (name == "") {
			$rd('.school_name_auto').remove();	
            }else {
            $rd.ajax({
            type: "POST",
            url: "/mentoringcommon/autopopulate",
            data: {
			id: 'school-attending',
            search: name
            },success: function(html) {
                 $rd('.school_name_auto').remove();
                 $rd("#edit-schoolattending").after(html);
            } 
		  });
 
       }
 
    });
	
	
	$rd("#edit-school-attending").keyup(function() { 
		    var name = $rd('#edit-school-attending').val();
			if (name == "") {
			$rd('.school_name_auto').remove();	
            }else {
            $rd.ajax({
            type: "POST",
            url: "/mentoringcommon/autopopulate",
            data: {
			id: 'school-attending1',	
            search: name
            },success: function(html) {
                 $rd('.school_name_auto').remove();
                 $rd("#edit-school-attending").after(html);
            } 
		  });
 
       }
 
    });
	
	
	$rd("#edit-lastschoolattended").keyup(function() { 
		    var name = $rd('#edit-lastschoolattended').val();
			if (name == "") {
			$rd('.school_name_auto').remove();	
            }else {
            $rd.ajax({
            type: "POST",
            url: "/mentoringcommon/autopopulate",
            data: {
			id: 'lastschool-attended',
            search: name
            },success: function(html) {
                 $rd('.school_name_auto').remove();
				 $rd("#edit-lastschoolattended").after(html);
            } 
		  });
 
       }
 
    });
	$rd("#edit-last-school-attended").keyup(function() { 
		    var name = $rd('#edit-last-school-attended').val();
			if (name == "") {
			$rd('.school_name_auto').remove();	
            }else {
            $rd.ajax({
            type: "POST",
            url: "/mentoringcommon/autopopulate",
            data: {
			id: 'last-school-attended',
            search: name
            },success: function(html) {
                 $rd('.school_name_auto').remove();
                 $rd("#edit-last-school-attended").after(html);
            } 
		  });
 
       }
 
    });
	
	$rd("#edit-highschoolname").keyup(function() { 
		    var name = $rd('#edit-highschoolname').val();
			if (name == "") {
			$rd('.school_name_auto').remove();	
            }else {
            $rd.ajax({
            type: "POST",
            url: "/mentoringcommon/autopopulate",
            data: {
			id: 'high-school',
            search: name
            },success: function(html) {
                 $rd('.school_name_auto').remove();
                 $rd("#edit-highschoolname").after(html);
            } 
		  });
 
       }
 
    });
	
	
	$rd("#edit-school-name, #edit-college-name, #edit-schoolattending, #edit-school-attending, #edit-lastschoolattended, #edit-last-school-attended ,#edit-highschoolname").focus(function() {
		$rd(this).val('');
	});
		/******************************  Phone validation *****************************/

          $rd("#edit-profile-schools-admin-field-phonereference-und-0-value").keypress(function (e) {
     //if the letter is not digit then display error and don't type anything
     if (e.which != 8 && e.which != 0 && e.which != 46 && (e.which < 48 || e.which > 57 )) {
        //display error message
		//alert('zczxczx');
		return false;
    }
	var curchr = $rd(this).val().length; 
		var curval = $rd(this).val();
		if (curchr == 3) {
			if(e.which != 8){
			$rd("#edit-profile-schools-admin-field-phonereference-und-0-value").val("(" + curval + ")");
			}
		} else if (curchr == 8) {
			if(e.which != 8){
			$rd("#edit-profile-schools-admin-field-phonereference-und-0-value").val(curval + "-");
			}
			
		}
		else if (curchr == 13) {
			 e.preventDefault();
			/*if(e.which != 8){
			$rd("#edit-profile-schools-admin-field-phonereference-und-0-value").val(curval + "-");
			}*/
		}
   });
		
		
		$rd("#mentoringcommon-login").attr('action','#errmessage');
		$rd("#edit-areaofmentoring-1").change(function(){
			if($rd(this).is(":checked")){
			$rd(".form-item-fieldOfStudy").parent().css('display','block');
			$rd(".form-item-fieldOfStudy").parent().parent().css('display','block');
			}else{
				
			$rd(".form-item-fieldOfStudy").parent().css('display','none');
			$rd(".form-item-fieldOfStudy").parent().parent().css('display','none');	
				
			}
		})
		
		
		/*$rd("a[href='/becomeskoolmentor']").attr('href','#');
		$rd("a[href='/becomeskoolmentor']").click(function(){
			$rd("#register-box").css('display', 'block');
			return false;
			
			
		}); */
if($rd("#mentee-profile-form #edit-mentee-type-transfer").prop('checked') == true){
console.log('vxvxcv');	
$rd('#edit-school-name').parent().parent().parent().parent().parent().css('display','none');
}else{
$rd('#edit-school-name').parent().parent().parent().parent().parent().css('display','block');	
}
		
		
		
		
		$rd(".tooltip_parent span").hover(function(){
			
			$rd(this).find('.skoolmentor-tooltip').css({"display":"block"},{"color":"#fff"});
		}, function(){
			
			$rd(this).find('.skoolmentor-tooltip').css("display",'none');
		});
		
		$rd(".tooltips").hover(function(){
			
			$rd(this).find('.skoolmentor-tooltip').css({"display":"block"},{"color":"#fff"});
		}, function(){
			
			$rd(this).find('.skoolmentor-tooltip').css("display",'none');
		});
		
		
		
		
		
		$rd('.panel-collapse').on('show.bs.collapse', function () {
	   $rd(this).siblings('.panel-heading').addClass('active');
	 });

	 $rd('.panel-collapse').on('hide.bs.collapse', function () {
	  $rd(this).siblings('.panel-heading').removeClass('active');
	 });
	 $rd("#mentoringcommon-login").attr('action','#errmessage');
		$rd("a[href='/becomeskoolmentor']").click(function(){
			$rd("#register-box").css('display', 'block');
			$rd(".form-item-usertype label").css('display','inline');
			return false;
			
			
		});
		 // $rd('#mentee-profile-form #edit-submit, #mentor-profile-form #edit-submit').click(function(e){
		 $rd('#mentor-profile-form #edit-submit').click(function(e){
		  var uploaded_image = $rd('#uploaded_image').val();
		  if(uploaded_image ==''){
			  e.preventDefault();
			  $rd('#prifile_pic_error').html('<div id="messages"><div class="section clearfix"><div class="messages error"><h2 class="element-invisible">Error message</h2><ul><li>Profile picture is required.</li></ul></div></div>');
			  $rd(window).scrollTop(0);
              return true;
		  }else{
			  
			  return true;
		  }
		  
		  
		  
	  });
		
		
		$rd('#edit-m-type-professional, #edit-mentor-type-professional').click(function(e){
			$rd("#edit-years-of-exp").parent().parent().css('display','block');
			$rd("#edit-last-school-attended").parent().parent().css('display','block');
			$rd("#edit-year-of-school").parent().parent().css('display','block');
			$rd(".form-item-yearOfSchool").css('display','block');
			$rd(".form-item-yearsOfExp").css('display','block');
			$rd("#edit-professional").parent().parent().css('display','block');
		    $rd('.current_location').text('Location Of Last School Attended'); 
		});
	  
	  $rd('#edit-m-type-student, #edit-mentor-type-student').click(function(e){
		  $rd('.form-item-expected-year-of-school').css('display','block');
	     $rd('.current_location').text('Current Location'); 
		 $rd("#edit-professional").parent().parent().css('display','none');
	  });
	  
	  if($rd("input[name=mentor_type]:checked").val() ==='professional'){
	     $rd('.current_location').text('Location Of Last School Attended');  
	  }else{
	     $rd('.current_location').text('Current Location'); 
		  
	  }
	  
	  $rd('#edit-transfer-highschool').change(function(){
		var trasfer_student =  $rd(this).val()
		 if(trasfer_student ==1){
			 
			 $rd('.trasfer_student').text('Community College Education Information');
			 $rd("label[for='edit-highschoolname']").html('Community College Name<div class="tooltip_parent"><span class="tooltips">? 		    <div class="skoolmentor-tooltip" style="display: none;"><p>If you do not see your high school/community college name here, it implies that your high school/community college is not registered with SkoolMentor. Please send an email to support@skoolmentor.com with your full name, the full name of your high school/community college including the school\'s complete mailing address requesting that your school be added to our database.</p></div></span></div>');
			 $rd("label[for='edit-yearofhighschool']").text('Year of Community College Graduation');
			 
			 $rd(".tooltips").hover(function(){
				 
				 console.log('i am hover');
			
			$rd(this).find('.skoolmentor-tooltip').css({"display":"block"},{"color":"#fff"});
		    }, function(){
			
			 $rd(this).find('.skoolmentor-tooltip').css("display",'none');
		    });
			 
			 /************************** Water Mark *********************************************/
		     var watermark = 'Community College Name';	         
	         $rd('#edit-highschoolname').val(watermark).addClass('watermark');	         
				$rd('#edit-highschoolname').blur(function(){
					if ($rd(this).val().length == 0){
						$rd(this).val(watermark).addClass('watermark');
					}
				});	         
				$rd('#edit-highschoolname').focus(function(){
					if ($rd(this).val() == watermark){
						$rd(this).val('').removeClass('watermark');
					}
				});
			 
			 
		    
			 
		 }else{
			$rd('.trasfer_student').text('High School Education Information');
            $rd("label[for='edit-highschoolname']").html('High School Name<div class="tooltip_parent"><span class="tooltips">? 		    <div class="skoolmentor-tooltip" style="display: none;"><p>If you do not see your high school/community college name here, it implies that your high school/community college is not registered with SkoolMentor. Please send an email to support@skoolmentor.com with your full name, the full name of your high school/community college including the school\'s complete mailing address requesting that your school be added to our database.</p></div></span></div>');
			 $rd("label[for='edit-yearofhighschool']").text('Year of Community College Graduation');
			 $rd("label[for='edit-yearofhighschool']").text('Year of High School Graduation');
			 
			 $rd(".tooltips").hover(function(){
				 
				 console.log('i am hover');
			
			$rd(this).find('.skoolmentor-tooltip').css({"display":"block"},{"color":"#fff"});
		    }, function(){
			
			 $rd(this).find('.skoolmentor-tooltip').css("display",'none');
		    });	
            
			$rd('#edit-highschoolname').attr('placeholder','Community College Name');
			var watermark = 'High School Name';	         
	         $rd('#edit-highschoolname').val(watermark).addClass('watermark');	         
				$rd('#edit-highschoolname').blur(function(){
					if ($rd(this).val().length == 0){
						$rd(this).val(watermark).addClass('watermark');
					}
				});	         
				$rd('#edit-highschoolname').focus(function(){
					if ($rd(this).val() == watermark){
						$rd(this).val('').removeClass('watermark');
					}
				});			
			 
		 }
	  });
	  
	   $rd("#edit-term-of-use").parent().hide();
	  $rd("#step_two").hide();
	  $rd('.dashboard-menu').on('click', 'li', function(){
			var name=$rd(this).find('a').attr('href');
			if(name=='#Connections' || name=='#Search' || name=='#onehour' || name=='#threemon'){
				$rd('.dashbaodr_title').text('CONNECTIONS');
				console.log(name);
				$rd('.cont').attr("style", "display: block !important");
				$rd('.graph-block').attr("style", "display: inline-block !important");
			}else{
				
				$rd('.cont').attr("style", "display: none !important");
				$rd('.graph-block').attr("style", "display: none !important");
			}
			if(name=='#view'){
				
				$rd('.dashbaodr_title').text('MY ACCOUNT');
			}
			else if(name=='#messages'){
				$rd('.dashbaodr_title').text('MENTORS');
			}
			else if(name=='#notification'){
				$rd('.dashbaodr_title').text('MENTEES');
			}
	  });
	  
	  
	  $rd("#step_three").hide();
	  $rd("#active_first").click(function(e){
		      $rd("#step_one").show();
			  $rd("#step_two").hide();
			  $rd("#step_three").hide();
			  $rd("#active_first").addClass('active');
			  $rd("#active_second").removeClass('active');
			  $rd("#active_third").removeClass('active');
			  
		  
	  });
		  $rd("#active_second").click(function(e){
			  
			  $rd("#step_one").hide();
			  $rd("#step_two").show();
			  $rd("#step_three").hide();
			  $rd("#active_first").removeClass('active');
			  $rd("#active_second").addClass('active');
			  $rd("#active_third").removeClass('active');
		  
		  });
		  $rd("#active_third").click(function(e){
			  
			  $rd("#step_one").hide();
			  $rd("#step_two").hide();
			  $rd("#step_three").show();
			  $rd("#active_first").removeClass('active');
			  $rd("#active_second").removeClass('active');
			  $rd("#active_third").addClass('active');
		  
		  });
	  
	  <!--------------   Step Second Mentee start ------------->
	  
	  $rd("#step_sec_mentee").click(function(e){ 
	  e.preventDefault();
	  //$rd('html, body').animate({scrollTop:$rd('#mentoringcommon-register-form').position().top}, 'slow');	   
	  var first_name = $rd('#edit-fname').val(); 	 
      var edit_gender = $rd('#edit-gender').val(); 
      var username = $rd('#edit-name').val();
	  var pass = $rd('#edit-pass-pass1').val();
      var confirm_pass = $rd('#edit-pass-pass2').val();
	  var pass_match = $rd('.password-confirm').find('.error').text();
	  var email = $rd('#edit-mail').val(); 
	  var confirm_email = $rd('#edit-confirm-mail').val();
	  var zipcode = $rd('#edit-zcode').val();
	  var edit_zipcode = $rd("#edit-zipcode").val();
	  var mobile = $rd("#edit-mobile").val();
	  var parentmail = $rd('#edit-parent-mail').val();
	  var pic = $rd('input[name="pic[fid]"]').val();
	  
	  zipcode = $rd.trim(zipcode);
	  mobile = $rd.trim(mobile);
	  if(first_name =='First Name *'){ console.log(1);
		    $rd('#name_msg').remove();
		   $rd("#edit-fname").after("<div id='name_msg' style='color:red;display: inline-block;padding-top: 5px !important;'>This field is required.</div>");
		   return false;
	  }else{
		 $rd('#name_msg').remove(); 
		  
	  } 
	  
	  if(edit_gender ==''){ console.log(2);
		  $rd("#gender_msg").remove(); 
		 $rd("#edit-gender").parent().after("<div id='gender_msg' style='color:red;display: inline-block;padding-top: 5px !important;'>This field is required.</div>");
          return false;		 
		  
	  }else{
		  
		  $rd("#gender_msg").remove();
	  }
	 
	  if($rd("#edit-name").length > 0 ){ console.log(3);
	  
	  if(username =='Username *'){
		$rd("#username_msg").remove();
		$rd("#edit-name").after("<div id='username_msg' style='color:red;display: inline-block;padding-top: 5px !important;'>This field is required.</div>");  
		return false;	  
	  }else{
		  
		 $rd("#username_msg").remove(); 
	  }
	  if(pass =='Password *'){
		$rd("#password_msg").remove();
		$rd("#edit-pass-pass1").after("<div id='password_msg' style='color:red;display: inline-block;padding-top: 0px !important;'>This field is required.</div>");  
		return false;	  
	  }else{
		  
		 $rd("#password_msg").remove(); 
	  }
	  if(confirm_pass =='Confirm password *'){
		 $rd("#cpassword_msg").remove();
		 $rd("#edit-pass-pass2").after("<div id='cpassword_msg' style='color:red;display: inline-block;padding-top: 0px !important;'>This field is required.</div>");  
		 return false;	  
	  }else{
		   $rd("#cpassword_msg").remove();
		  if(pass_match =='no'){
			$rd("#edit-pass-pass2").after("<div id='cpassword_msg' style='color:red;display: inline-block;padding-top: 0px !important;'>Passord does not matched.</div>");
			/*$rd('#cpassword_msg').text('Passord does not matched');*/
            return false;			
			  
		  }
		 $rd("#cpassword_msg").remove(); 
	  }
	  if(email =='E-mail address *'){
		
        $rd("#edit-mail").after("<div id='email_msg' style='color:red;display: inline-block;padding-top: 5px !important;'>This field is required.</div>");		
        return false;	
	
	  }else{
		  
		$rd("#email_msg").remove();  
	  }
	  if( !validateEmail(email)) {
		   $rd("#edit-mail").after("<div id='email_msg' style='color:red;display: inline-block;padding-top: 5px !important;'>Must be valid email. example@yourdomain.com</div>"); 
		   return false;						
		}else{
			
			$rd("#email_msg").remove();
	  }
	  if(email){ //alert(email);
				 $rd.ajax({
				    type: "GET",
				    url: "/mentoringcommon/existedemail",//Drupal.settings.mentoringcommon.ajaxUrl,
				    data: {email: email},
                    async: false,				   // serializes the form's elements.
				    success: function(data){
					   if(data == 'matched'){
						   $rd("#email_msg").remove(); 
						   $rd("#edit-mail").after("<div id='email_msg' style='color:red;display: inline-block;padding-top: 5px !important;'>Email already exists, please try another.</div>"); 
						  return false; 
					   }
					   if(data == 'non_matched'){
						   
						$rd("#email").remove();   
						   
					   } // show response from the php script.
					}
				 });
				 }
	  <!---         Confirm email ---->
	  
	  if(confirm_email =='Confirm E-mail address *'){
        $rd("#cemail").remove();		  
        $rd("#edit-confirm-mail").after("<div id='cemail' style='color:red;display: inline-block;padding-top: 5px !important;'>This field is required.</div>");		
        return false;	
	
	  }else{
		  
		$rd("#cemail").remove();  
	  }
	  if(!validateEmail(confirm_email)) {
		   $rd("#edit-confirm-mail").after("<div id='cemail' style='color:red;display: inline-block;padding-top: 5px !important;'>Must be valid email. example@yourdomain.com</div>"); 
		   return false;						
		}else{
			if(email != confirm_email){
				
			 $rd("#edit-confirm-mail").after("<div id='cemail' style='color:red;display: inline-block;padding-top: 5px !important;'>Email does not match.</div>");
             return false;			 
				
			}
			
			
			$rd("#cemail").remove();
			
			
			
	  }
	  }
	  if($rd('#edit-parent-mail').length > 0){
		  
		  if(parentmail =='Parent E-mail address *' || parentmail==''){
			
		$rd("#parentmail_msg").remove();
		$rd("#edit-parent-mail").after("<div id='parentmail_msg' style='color:red;display: inline-block;padding-top: 5px !important;'>This field is required.</div>");  
		return false;	  
	  }else{
		  
		 $rd("#parentmail_msg").remove();
         if(!validateEmail(parentmail)) {
		   $rd("#edit-parent-mail").after("<div id='parentmail_msg' style='color:red;display: inline-block;padding-top: 5px !important;'>Must be valid email. example@yourdomain.com</div>"); 
		   return false;						
		}else{
			if(email == parentmail){
				
			 $rd("#edit-parent-mail").after("<div id='parentmail_msg' style='color:red;display: inline-block;padding-top: 5px !important;'>Parent Mail Address cannot be the same as Mentee Mail Address</div>");
             return false;			 
				
			}
			
			
			$rd("#cemail").remove();		 
			  
			  
		  }
	  }
	  }
	  if($rd("#edit-zcode").length > 0){ console.log(4);
	  if(zipcode =='Zip code *'){
		$rd("#zcode_msg").remove();
		$rd("#edit-zcode").after("<div id='zcode_msg' style='color:red;display: inline-block;padding-top: 5px !important;'>This field is required.</div>");  
		return false;	  
	  }else{
		  
		 $rd("#zcode_msg").remove(); 
		 if(!validatezipcode(zipcode)){ console.log(zipcode);
			$rd("#edit-zcode").after("<div id='zcode_msg' style='color:red;display: inline-block;padding-top: 5px !important;'>Zip Code Should be 5 digit (XXXXX).</div>"); 
			return false;
			 
		 }
		
	  }
	  }
	  if($rd("#edit-zipcode").length > 0){  console.log(5);
		  
	if(edit_zipcode ==''){
		$rd("#zcode_msg").remove();
		$rd("#edit-zipcode").after("<div id='zcode_msg' style='color:red;display: inline-block;padding-top: 5px !important;'>This field is required.</div>");  
		return false;	  
	  }else{
		  
		 $rd("#zcode_msg").remove(); 
		 
		 if(!validatezipcode(edit_zipcode)){
			$rd("#edit-zipcode").after("<div id='zcode_msg' style='color:red;display: inline-block;padding-top: 5px !important;'>Zip Code Should be 5 digit (XXXXX).</div>");
            return false;			
			 
		 }else{
			$rd("#zcode_msg").remove(); 
			 
		 }
		
	  } 
		  
	  }
	 if(mobile.length > 0 ){
	 if(mobile !='Mobile'){ console.log('6wwww');
	  if(!validatePhoneNumber(mobile)){
		  $rd("#mobile_msg").remove();
		  $rd("#edit-mobile").after("<div id='mobile_msg' style='color:red;display: inline-block;padding-top: 5px !important;'>Mobile number must be in the format (xxx)xxx-nnnn.</div>");
		  return false;
		  
		  
	  }else{
		  $rd("#mobile_msg").remove();  
		  
	  }
	   }
	   }
	   /*if($rd("#mentoringcommon-register-form #edit-pic-upload").length > 0){ console.log('7eee'); 
		   
		   if(pic == 0){
			  $rd("#pic_msg").remove();
			  $rd("#edit-pic-upload-button").after("<div id='pic_msg' style='color:red;display: inline-block;padding-top: 5px !important;width:100%'>This field is required.</div>");
			  return false;
			   
		   }else{
			   
			  $rd("#pic_msg").remove(); 
			   
		   }
		   
	   } */
	  
	   if($rd("#email_msg").length > 0) {  console.log('6dadadas'); 
                
				return false;
				}
				
				
		   
		   
		  $rd("#step_one").hide();
		  $rd("#step_two").show();
		  $rd("#step_three").hide();
		  $rd("#active_first").removeClass('active');
		  $rd("#active_second").addClass('active');
		  
		  
		  
	  });
	  
	   <!--------------   Step Second Mentee End  ------------->
	   <!--------------   Step Second Mentor Start  ------------->
	  
	  $rd("#step_sec_mentor").click(function(e){
		   e.preventDefault();
	  //$rd('html, body').animate({scrollTop:$rd('#mentoringcommon-register-form').position().top}, 'slow');	   
	  var first_name = $rd('#edit-fname').val(); 	 
      var edit_gender = $rd('#edit-gender').val(); 
      var username = $rd('#edit-name').val();
	  var pass = $rd('#edit-pass-pass1').val();
      var confirm_pass = $rd('#edit-pass-pass2').val();
	  var pass_match = $rd('.password-confirm').find('.error').text();
	  var email = $rd('#edit-mail').val(); 
	  var confirm_email = $rd('#edit-confirm-mail').val();
	  var zipcode = $rd('#edit-zcode').val();
	  var edit_zipcode = $rd("#edit-zipcode").val();
	  var mobile = $rd("#edit-mobile").val(); 
	  var pic = $rd('input[name="pic[fid]"]').val();
	  var uploaded_image = $rd("#uploaded_image").val();
	  //var zipcode = $rd('#edit-zcode').val();
	  
	  
	  zipcode = $rd.trim(zipcode);
	  mobile = $rd.trim(mobile); 
	  
	  if($rd("#uploaded_image").length > 0 ){  console.log(1);
	     if(uploaded_image ==''){
			 $rd('#uploadimage_msg').remove();
			 $rd("#user-pic-div").parent('.profile-data').after("<div id='uploadimage_msg' style='color:red;display: inline-block;padding-top: 5px !important;'>Please upload image.</div>");
			  $rd('html, body').animate({
        scrollTop: $rd('.mentor-profile-wrapper').offset().top
    }, 1000);
		     return false;
		 }else{
			 $rd('#uploadimage_msg').remove();
			 
		 }
	  
	  }

     if($rd("#uploaded_image").length ==''){  
	     //if(uploaded_image ==''){
			  console.log('czxczxc');
			 $rd('#uploadimage_msg').remove();
			 $rd("#user-pic-div").parent('.profile-data').after("<div id='uploadimage_msg' style='color:red;display: inline-block;padding-top: 5px !important;'>Please upload image.</div>");
			  $rd('html, body').animate({
        scrollTop: $rd('.mentor-profile-wrapper').offset().top
    }, 1000);
		     return false;
		 }else{
			 $rd('#uploadimage_msg').remove();
			 
		 }	  
	  
	  if(first_name =='First Name *'){ console.log(1);
		    $rd('#name_msg').remove();
		   $rd("#edit-fname").after("<div id='name_msg' style='color:red;display: inline-block;padding-top: 5px !important;'>This field is required.</div>");
		   return false;
	  }else{
		 $rd('#name_msg').remove(); 
		  
	  } 
	  if(edit_gender ==''){ console.log(1);
		  $rd("#gender_msg").remove(); 
		 $rd("#edit-gender").parent().after("<div id='gender_msg' style='color:red;display: inline-block;padding-top: 5px !important;'>This field is required.</div>");
          return false;		 
		  
	  }else{
		  
		  $rd("#gender_msg").remove();
	  }
	  if($rd("#edit-name").length > 0 ){  console.log(1);
	  if(username =='Username *'){
		$rd("#username_msg").remove();
		$rd("#edit-name").after("<div id='username_msg' style='color:red;display: inline-block;padding-top: 5px !important;'>This field is required.</div>");  
		return false;	  
	  }else{
		  
		 $rd("#username_msg").remove(); 
	  }
	  if(pass =='Password *'){
		$rd("#password_msg").remove();
		$rd("#edit-pass-pass1").after("<div id='password_msg' style='color:red;display: inline-block;padding-top: 0px !important;'>This field is required.</div>");  
		return false;	  
	  }else{
		  
		 $rd("#password_msg").remove(); 
	  }
	  if(confirm_pass =='Confirm password *'){
		 $rd("#cpassword_msg").remove();
		 $rd("#edit-pass-pass2").after("<div id='cpassword_msg' style='color:red;display: inline-block;padding-top: 0px !important;'>This field is required.</div>");  
		 return false;	  
	  }else{
		   $rd("#cpassword_msg").remove();
		  if(pass_match =='no'){
			$rd("#edit-pass-pass2").after("<div id='cpassword_msg' style='color:red;display: inline-block;padding-top: 0px !important;'>Password does not matched.</div>");
			/*$rd('#cpassword_msg').text('Passord does not matched');*/
            return false;			
			  
		  }
		 $rd("#cpassword_msg").remove(); 
	  }
	  }
	  if($rd("#edit-zcode").length > 0){
	  if(zipcode =='Zip code *'){
		$rd("#zcode_msg").remove();
		$rd("#edit-zcode").after("<div id='zcode_msg' style='color:red;display: inline-block;padding-top: 5px !important;'>This field is required.</div>");  
		return false;	  
	  }else{
		 $rd("#zcode_msg").remove();
         if(!validatezipcode(zipcode)){ 
			 $rd("#edit-zcode").after("<div id='zcode_msg' style='color:red;display: inline-block;padding-top: 5px !important;'>Zip code should be 5 digit(XXXXX).</div>");
			 return false;
			 
		 }else{
			$rd("#zcode_msg").remove(); 
			 
		 }		 
		 //alert($rd("#email").length);
		
	  }
	  }
	  
	  if($rd("#edit-zipcode").length > 0){ 
		  
	if(edit_zipcode ==''){
		$rd("#username_msg").remove();
		$rd("#edit-zipcode").after("<div id='zcode_msg' style='color:red;display: inline-block;padding-top: 5px !important;'>This field is required.</div>");  
		return false;	  
	  }else{
		  
		 $rd("#zcode_msg").remove(); 
		 //alert($rd("#email").length);
		
	  } 
		  
	  }
	  if(mobile.length > 0 ){ 
	  if(mobile !='Mobile'){
	  if(!validatePhoneNumber(mobile)){
		  $rd("#mobile_msg").remove();
		  $rd("#edit-mobile").after("<div id='mobile_msg' style='color:red;display: inline-block;padding-top: 5px !important;'>Mobile number must be in the format (xxx)xxx-nnnn.</div>");
		  return false;
		  
		  
	  }else{
		  $rd("#mobile_msg").remove();  
		  
	  }
	  }
	  }
	  if($rd("#mentoringcommon-register-form #edit-pic-upload").length > 0){
		   
		   if(pic == 0){
			  $rd("#pic_msg").remove();
			  $rd("#edit-pic-upload-button").after("<div id='pic_msg' style='color:red;display: inline-block;padding-top: 5px !important;width:100%'>This field is required.</div>");
			  return false;
			   
		   }else{
			   
			  $rd("#pic_msg").remove(); 
			   
		   }
		   
	   }
	   
/* 	  $rd("#edit-mentor-type-professional").prop("checked", true);
	  $rd("#edit-professional").parent().parent().css({"display": "block"});
	  $rd("#edit-professional").css({"display": "block"});
	   
	  if(!$rd('#edit-professional').is(':visible')){
		  $rd(".form-item-employer").css({"display": "block"});
	      $rd(".form-item-title").css({"display": "block"});
		  $rd(".form-item-years-of-exp").css({"display": "block"});
	      $rd(".form-item-linkedInProfile").css({"display": "block"});
		  $rd(".form-item-last-school-attended").css({"display": "block"});
		  $rd(".form-item-year-of-school").css({"display": "block"});
		  $rd(".form-item-workemail").css({"display": "block"});
		  $rd(".form-item-confirm-workemail").css({"display": "block"});
          
		} */
 
	  $rd("#step_one").hide();
	  $rd("#step_two").show();
	  $rd("#step_three").hide();
	  $rd("#active_first").removeClass('active');
	  $rd("#active_second").addClass('active');
	  });
	  
	   <!--------------   Step Second Mentor End  -------------> 
	   
	   <!--------------   Step Third Mentee End  ------------->
	  
	  $rd("#step_third_mentee").click(function(e){ console.log('0'); 
		   e.preventDefault();
		   var schoolname = $rd("#edit-school-name").val();
		   var yrofgrad = $rd("#edit-yearofschool").val();
		   var clgname = $rd("#edit-college-name").val();
           clgname = $rd.trim(clgname);
		   var yrofintrans  = $rd("#edit-yearofintendedtransfer").val();
		   var country = $rd("#edit-country").val();
		   var state = $rd("#edit-stateusa").val();
		   var city = $rd("select[name^=cityUSA]").val();
		   schoolname = $rd.trim(schoolname)
		   
		   if($rd("#edit-mentee-type-highschool").prop('checked') == true){ console.log('1');
		   if(schoolname == 'School Name *' || schoolname == ''){
			$rd("#schname_msg").remove();
			$rd("#edit-school-name").parent().after("<div id='schname_msg' style='color:red;display: inline-block;padding-top: 10px !important;'>This field is required.</div>");  
			return false;	  
		   } else {
			   
			   $rd.ajax({
				    type: "POST",
				    url: "/mentoringcommon/chkschlname",//Drupal.settings.mentoringcommon.ajaxUrl,
				    data: {schoolname: schoolname},
                    async: false,				   // serializes the form's elements.
				    success: function(data){
					   if(data == 'non_matched'){
						   $rd("#schname_msg").remove(); 
						   $rd('.school_name_auto').css('display','none');
						   $rd("#edit-school-name").after("<div id='schname_msg' style='color:red;display: inline-block;padding-top: 5px !important;'>Please select your school name from the dropdown list.</div>"); 
						  return false; 
					   }
					   if(data == 'matched'){
						   
						$rd("#schname_msg").remove();   
						   
					   } // show response from the php script.
					}
				 });
			   
			   
			  
			  
		  }
		  if(yrofgrad ==''){ console.log('2');
			$rd("#yrofgrad_msg").remove();
			$rd("#edit-yearofschool").parent().after("<div id='yrofgrad_msg' style='color:red;display: inline-block;padding-top: 10px !important;'>This field is required.</div>");  
			return false;	  
		   } else {
			  
			 $rd("#yrofgrad_msg").remove(); 
		  }
		  
		  }
		  if($rd("#edit-mentee-type-transfer").prop('checked') == true){ console.log('2');
			  
			if(clgname =='Current College Name *' || clgname ==''){
			$rd("#colname_msg").remove();
			$rd("#edit-college-name").after("<div id='colname_msg' style='color:red;display: inline-block;padding-top: 10px !important;'>This field is required.</div>");  
			return false;	  
		   } else {
			   
			   $rd.ajax({
				    type: "POST",
				    url: "/mentoringcommon/chkschlname",//Drupal.settings.mentoringcommon.ajaxUrl,
				    data: {schoolname: clgname},
                    async: false,				   // serializes the form's elements.
				    success: function(data){
					   if(data == 'non_matched'){
						   $rd("#colname_msg").remove(); 
						   $rd('.school_name_auto').css('display','none');
						   $rd("#edit-college-name").after("<div id='colname_msg' style='color:red;display: inline-block;padding-top: 5px !important;'>Please select your college name from the dropdown list.</div>"); 
						  return false; 
					   }
					   if(data == 'matched'){
						   
						$rd("#colname_msg").remove();   
						   
					   } // show response from the php script.
					}
				 });
			  
			 
		  }
		  if(yrofintrans ==''){ console.log('4');
			$rd("#yrofintrans_msg").remove();
			$rd("#edit-yearofintendedtransfer").parent().after("<div id='yrofintrans_msg' style='color:red;display: inline-block;padding-top: 10px !important;'>This field is required.</div>");  
			return false;	  
		   } else {
			  
			 $rd("#yrofintrans_msg").remove(); 
		  } 
			  
		  }
		  
		  /*if(country ==''){  console.log('5');
			$rd("#country_msg").remove();
			$rd("#edit-country").parent().after("<div id='country_msg' style='color:red;display: inline-block;padding-top: 10px !important;'>This field is required.</div>");  
			return false;	  
		   } else {
			  
			 $rd("#country_msg").remove(); 
		  }
		  if(state ==''){  console.log('6');
			$rd("#country_msg").remove();
			$rd("#edit-stateusa").parent().after("<div id='state_msg' style='color:red;display: inline-block;padding-top: 10px !important;'>This field is required.</div>");  
			return false;	  
		   } else {
			  
			 $rd("#state_msg").remove(); 
		  }
		  if(city ==''){ console.log('7');
			$rd("#city_msg").remove();
			$rd("select[name^=cityUSA").parent().after("<div id='city_msg' style='color:red;display: inline-block;padding-top: 10px !important;'>This field is required.</div>");  
			return false;	  
		   } else {
			  
			 $rd("#city_msg").remove(); 
		  }*/
		  
		   if($rd('#schname_msg').length > 0){
			   
			   return false;
		   }
		   if($rd('#colname_msg').length > 0){
			   
			   return false;
		   }
		   
		   
		   
		   
		  $rd("#step_one").hide();
		  $rd("#step_two").hide();
		  $rd("#step_three").show();
		  $rd("#active_second").removeClass('active');
		  $rd("#active_third").addClass('active');
		  $rd("#edit-term-of-use").parent().show();
		  
	  });
	  
	  
	  <!--------------   Step Third Mentee End  ------------->
	  
	  
	  <!--------------   Step Third Mentor Start  ------------->
	  $rd("#step_third_mentor").click(function(e){
		  e.preventDefault();
		  var school_attend = $rd('#edit-schoolattending').val();
		  var expyrofschl = $rd('#edit-expectedyearofschool').val();
          var colgmail = $rd('#edit-collegeemail').val();
		  var cfmcglmail = $rd('#edit-confirm-collegeemail').val();
		  var country = $rd("#edit-country").val();
		  var state = $rd("#edit-stateusa").val();
		  var city = $rd("select[name^=cityUSA]").val();
		  var employer = $rd("#edit-employer").val();
		  var title = $rd("#edit-title").val();
		  var yearofexp = $rd("#edit-yearsofexp").val();
		  var lastschattd = $rd("#edit-lastschoolattended").val();
		  var yrofschool = $rd("#edit-yearofschool").val();
		  var workmail  =  $rd("#edit-workemail").val();
		  var cofrmworkmail = $rd("#edit-confirm-workemail").val();
		  var transhighsch = $rd("#edit-transfer-highschool").val();
		  var high_schl_name = $rd("#edit-highschoolname").val();
		  console.log('transfer-school'+ transhighsch);
		   console.log('transfer-school-name'+ high_schl_name);
		  if($rd('#edit-m-type-student').prop('checked') == true){ console.log("1");
			 //if($rd('#edit-m-type-student').is(':checked')){
			 if(school_attend ==''){
				 
				 $rd("#sch_att_msg").remove();
			$rd("#edit-schoolattending").parent().after("<div id='sch_att_msg' style='color:red;display: inline-block;padding-top: 10px !important;'>This field is required.</div>");  
			return false;
				 
			 }else{
				 
				$rd.ajax({
				    type: "POST",
				    url: "/mentoringcommon/chkschlname",//Drupal.settings.mentoringcommon.ajaxUrl,
				    data: {schoolname: school_attend},
                    async: false,				   // serializes the form's elements.
				    success: function(data){
					   if(data == 'non_matched'){
						   $rd("#sch_att_msg").remove(); 
						   $rd('.school_name_auto').css('display','none');
						   $rd("#edit-schoolattending").after("<div id='sch_att_msg' style='color:red;display: inline-block;padding-top: 5px !important;'>Please select your school name from the dropdown list.</div>"); 
						  return false; 
					   }
					   if(data == 'matched'){
						   
						$rd("#sch_att_msg").remove();   
						   
					   } // show response from the php script.
					}
				 }); 
				
                //$rd("#sch_att_msg").remove(); 				
				 
			 }
			 if(expyrofschl ==''){ console.log("2");
				 
				 $rd("#expyrofschl").remove();
				$rd("#edit-expectedyearofschool").parent().after("<div id='expyrofschl' style='color:red;display: inline-block;padding-top: 10px !important;'>This field is required.</div>");  
				return false;
				 
			 }else{
				
                $rd("#expyrofschl").remove(); 				
				 
			 }
			 if(colgmail =='College E-mail Address *'){ console.log("3");
				 
				 $rd("#colgmail").remove();
				$rd("#edit-collegeemail").after("<div id='colgmail' style='color:red;display: inline-block;padding-top: 10px !important;'>This field is required.</div>");  
				return false;
				 
			 }else{
				
                $rd("#colgmail").remove(); 				
				 
			 }
			 if( !validateEmailedu(colgmail)) {
			   $rd("#edit-collegeemail").after("<div id='colgmail' style='color:red;display: inline-block;padding-top: 5px !important;'>Must be valid email. example@yourdomain.edu</div>"); 
			   return false;						
		 }else{
			
			$rd("#colgmail").remove();
			if(colgmail){ //alert(email);
				 $rd.ajax({
				    type: "GET",
				    url: "/mentoringcommon/existedemail",//Drupal.settings.mentoringcommon.ajaxUrl,
				    data: {email: colgmail},
                    async: false,				   // serializes the form's elements.
				    success: function(data){
					   if(data == 'matched'){
						   $rd("#colgmail").remove(); 
						   $rd("#edit-collegeemail").after("<div id='colgmail' style='color:red;display: inline-block;padding-top: 5px !important;'>Email already exists, please try another.</div>"); 
						  return false; 
					   }
					   if(data == 'non_matched'){
						   
						$rd("#colgmail").remove();   
						   
					   } // show response from the php script.
					}
				 });
		     }
	  }
	   
	  
	  
	  
	  if(cfmcglmail =='Confirm Work E-mail Address *'){ console.log("4");
				 
				 $rd("#cfmcglmail").remove();
				$rd("#edit-confirm-collegeemail").after("<div id='cfmcglmail' style='color:red;display: inline-block;padding-top: 10px !important;'>This field is required.</div>");  
				return false;
				 
			 }else{
				
                $rd("#cfmcglmail").remove(); 				
				 
			 }
			 
			 if(colgmail != cfmcglmail){
				
			 $rd("#edit-confirm-collegeemail").after("<div id='cfmcglmail' style='color:red;display: inline-block;padding-top: 5px !important;'>Email does not match.</div>");
             return false;			 
				
			}else{
				
			$rd("#cfmcglmail").remove(); 	
			}
			
			
			
	  
			 
			
			 
		 }
		 if($rd('#edit-m-type-professional').prop('checked') == true || $rd('#edit-mentor-type-professional').prop('checked') == true){ console.log("5qqq");
			if(employer =='Employer *' || employer== ''){
			$rd("#empoyer_msg").remove();
			$rd("#edit-employer").after("<div id='empoyer_msg' style='color:red;display: inline-block;padding-top: 10px !important;'>This field is required.</div>");  
			return false;	  
		   } else {
			  
			 $rd("#empoyer_msg").remove(); 
		  }
		  
		  if(title =='Job Title *' || title ==''){ console.log("6");
			$rd("#title_msg").remove();
			$rd("#edit-title").after("<div id='title_msg' style='color:red;display: inline-block;padding-top: 10px !important;'>This field is required.</div>");  
			return false;	  
		   } else {
			  
			 $rd("#title_msg").remove(); 
		  }
		 if(yearofexp =='' || yearofexp ==''){  console.log("7");
			$rd("#yearofexp").remove();
			$rd("#edit-yearsofexp").after("<div id='yearofexp' style='color:red;display: inline-block;padding-top: 10px !important;'>This field is required.</div>");  
			return false;	  
		   } else {
			  
			 $rd("#yearofexp").remove(); 
		  } 
		  
		  if(lastschattd =='Last School Attended *' || lastschattd==''){ console.log("8");
			$rd("#lastschattd").remove();
			$rd("#edit-lastschoolattended").after("<div id='lastschattd' style='color:red;display: inline-block;padding-top: 10px !important;'>This field is required.</div>");  
			return false;	  
		   } else {
			  
			 $rd.ajax({
				    type: "POST",
				    url: "/mentoringcommon/chkschlname",//Drupal.settings.mentoringcommon.ajaxUrl,
				    data: {schoolname: lastschattd},
                    async: false,				   // serializes the form's elements.
				    success: function(data){
					   if(data == 'non_matched'){
						   $rd("#lastschattd").remove(); 
						   $rd('.school_name_auto').css('display','none');
						   $rd("#edit-lastschoolattended").after("<div id='lastschattd' style='color:red;display: inline-block;padding-top: 5px !important;'>Please select your school name from the dropdown list.</div>"); 
						  return false; 
					   }
					   if(data == 'matched'){
						   
						$rd("#lastschattd").remove();   
						   
					   } // show response from the php script.
					}
				 }); 
		  }
		  if(yrofschool =='' || yrofschool==''){ console.log("9");
			$rd("#yrofschool").remove();
			$rd("#edit-yearofschool").after("<div id='yrofschool' style='color:red;display: inline-block;padding-top: 10px !important;'>This field is required.</div>");  
			return false;	  
		   } else {
			  
			 $rd("#yrofschool").remove(); 
		  }
		  
		  
		  if(workmail =='Work E-mail Address *' || workmail ==''){ console.log("10");
				 
				 $rd("#colgmail").remove();
				$rd("#edit-workemail").after("<div id='colgmail' style='color:red;display: inline-block;padding-top: 10px !important;'>This field is required.</div>");  
				return false;
				 
			 }else{
				
                $rd("#colgmail").remove(); 				
				 
			 }
			 if(!workemailprofessional(workmail)) {
			   $rd("#edit-workemail").after("<div id='colgmail' style='color:red;display: inline-block;padding-top: 5px !important;'>Personal email address (like yahoo.com, gmail.com is not allowed)</div>"); 
			   return false;						
		 }else{
			if($rd("#mentoringcommon-register-form #edit-workemail").length > 0){
			$rd("#colgmail").remove();
			if(workmail){ //alert(email);
				 $rd.ajax({
				    type: "GET",
				    url: "/mentoringcommon/existedemail",//Drupal.settings.mentoringcommon.ajaxUrl,
				    data: {email: workmail},
                    async: false,				   // serializes the form's elements.
				    success: function(data){
					   if(data == 'matched'){
						   $rd("#colgmail").remove(); 
						   $rd("#edit-workemail").after("<div id='colgmail' style='color:red;display: inline-block;padding-top: 5px !important;'>Email already exists, please try another.</div>"); 
						  return false; 
					   }
					   if(data == 'non_matched'){
						   
						$rd("#colgmail").remove();   
						   
					   } // show response from the php script.
					}
				 });
		     }
			}
	  }
	   
	  
	  
	  
	  if(cofrmworkmail =='Confirm Work E-mail Address *' || cofrmworkmail ==''){ console.log("12");
				 
				 $rd("#cfmcglmail").remove();
				$rd("#edit-confirm-workemail").after("<div id='cfmcglmail' style='color:red;display: inline-block;padding-top: 10px !important;'>This field is required.</div>");  
				return false;
				 
			 }else{
				
                $rd("#cfmcglmail").remove(); 				
				 
			 }
			 
			 if(workmail != cofrmworkmail){
				
			 $rd("#edit-confirm-workemail").after("<div id='cfmcglmail' style='color:red;display: inline-block;padding-top: 5px !important;'>Email does not match.</div>");
             return false;			 
				
			}else{
				
			$rd("#cfmcglmail").remove(); 	
			}
			
			
			
			
			
			 
		 }
		 if(transhighsch ==1){
			 
			if(high_schl_name =='' || high_schl_name=='Community College Name'){
				 
			$rd("#tran_high_msg").remove();
			$rd("#edit-highschoolname").parent().after("<div id='tran_high_msg' style='color:red;display: inline-block;padding-top: 10px !important;'>This field is required.</div>");  
			return false;
				 
			 }else{
				 
				$rd.ajax({
				    type: "POST",
				    url: "/mentoringcommon/chkschlname",//Drupal.settings.mentoringcommon.ajaxUrl,
				    data: {schoolname: high_schl_name},
                    async: false,				   // serializes the form's elements.
				    success: function(data){
					   if(data == 'non_matched'){
						   $rd("#tran_high_msg").remove(); 
						   $rd('.school_name_auto').css('display','none');
						   $rd("#edit-highschoolname").after("<div id='tran_high_msg' style='color:red;display: inline-block;padding-top: 5px !important;'>Please select your school name from the dropdown list.</div>"); 
						  return false; 
					   }
					   if(data == 'matched'){
						   
						$rd("#tran_high_msg").remove();   
						   
					   } // show response from the php script.
					}
				 }); 
				
                			
				 
			 } 
			 
		 }
		 /*if(country ==''){ console.log("13");
			$rd("#country_msg").remove();
			$rd("#edit-country").parent().after("<div id='country_msg' style='color:red;display: inline-block;padding-top: 10px !important;'>This field is required.</div>");  
			return false;	  
		   } else {
			  
			 $rd("#country_msg").remove(); 
		  }
		  if(state ==''){
			$rd("#state_msg").remove();
			$rd("#edit-stateusa").parent().after("<div id='state_msg' style='color:red;display: inline-block;padding-top: 10px !important;'>This field is required.</div>");  
			return false;	  
		   } else {
			  
			 $rd("#state_msg").remove(); 
		  }
		  if(city ==''){ console.log("14");
			$rd("#city_msg").remove();
			$rd("select[name^=cityUSA]").parent().after("<div id='city_msg' style='color:red;display: inline-block;padding-top: 10px !important;'>This field is required.</div>");  
			return false;	  
		   } else {
			  
			 $rd("#city_msg").remove(); 
		  } */
		  
		    if($rd("#colgmail").length > 0) { console.log("15");
                
				return false;
				}
				if($rd("#sch_att_msg").length > 0) { console.log("15");
                
				return false;
				}
				if($rd("#lastschattd").length > 0) { console.log("15");
                
				return false;
				}
				if($rd("#tran_high_msg").length > 0) { console.log("15");
                
				return false;
				}
				
		 //alert($rd('#edit-m-type-student:checkbox:checked').length); return false;
		 
		 $rd("#step_one").hide();
		 $rd("#step_two").hide();
		 $rd("#step_three").show();
		 $rd("#active_second").removeClass('active');
		 $rd("#active_third").addClass('active');
		 $rd("#edit-term-of-use").parent().show();
		  
		  
	  });

<!--------------   Step Third Mentor End  ------------->

<!---------------  submit Mentor/mentee start   ------------>	  
	  
	  $rd('#mentoringcommon-register-form #edit-submit').click(function(e){
		  //e.preventDefault();
		  var mentorsignup = $rd('#mentoringcommon-register-form').attr('action');
		  var domain = mentorsignup.slice(1,7);
		  if(domain =='mentor'){
		     var pic = $rd('input[name="pic[fid]"]').val();
             if($rd("#mentoringcommon-register-form #edit-pic-upload").length > 0){
		        if(pic == 0){
				   $rd("#pic_msg").remove();
				   $rd("#termandcondition").after("<div id='pic_msg' style='color:red;display: inline-block;padding-top: 5px !important;width:100%;text-align: center'>Some of required fields are empty.</div>");
				   return false;
				   
			    }else{
				   $rd("#pic_msg").remove(); 
				}
		    }			
		  }
		  var areaofment = $rd('.form-item-areaofmentoring .form-checkbox:checkbox:checked').length;
		  var fldofspe = $rd(".form-item-fieldOfSpecialization .form-checkbox:checkbox:checked").length;
		  var degree = $rd("#edit-degree").val();
		  if(areaofment < 1){
			  e.preventDefault();
			$rd("#armtr_msg").remove();
			$rd(".form-item-areaofmentoring").after("<div id='armtr_msg' style='color:red;display: inline-block;padding-top: 10px !important;'>This field is required.</div>");  
			return false; 
			 
		  }else{
			  
			  $rd("#armtr_msg").remove(); 
			  
			  
			 
			 
		  }
		  if($rd("#mentee_dropdown_specialization_replace_1").parent().parent().css('display') == 'block' || $rd("#dropdown_specialization_replace_1").parent().parent().css('display') == 'block'){
		  if(fldofspe < 1){
			  e.preventDefault();
			$rd("#fldofspe_msg").remove();
			$rd(".form-item-fieldOfSpecialization").after("<div id='fldofspe_msg' style='color:red;display: inline-block;padding-top: 10px !important;'>This field is required.</div>");  
			return false;
			  
		  }else{
			  
			  
			$rd("#fldofspe_msg").remove();  
		  }
		  }
		  
		  if($rd("#edit-degree").length > 0){
			 if(degree ==''){
				$rd("#degree").remove();
				$rd("#edit-degree").after("<div id='degree' style='color:red;display: inline-block;padding-top: 10px !important;'>This field is required.</div>");  
				return false;	 
				 
			 }else{
				 
				 
				 $rd("#degree").remove();
			 }
             			 
			 
		  }
		  
		  
		  
		  var termcond = $rd('#edit-mentoring-terms:checkbox:checked').length;
		  if(termcond < 1){
			  e.preventDefault();
			$rd("#termcond_msg").remove();
			$rd("#termandcondition").after("<div id='termcond_msg' style='color:red;display: inline-block;padding-top: 10px !important;'>This field is required.</div>");  
			return false; 
			 
		  }else{
			  
			  $rd("#termcond_msg").remove(); 
			  return true;
			  
		  }
		  
		  
	  });
	  <!------------------   Mentor Profile start  ------------------>
	  $rd('#mentor-profile-form #edit-submit').click(function(e){
		  //e.preventDefault();
		  var areaofment = $rd('.form-item-areaofmentoring .form-checkbox:checkbox:checked').length;
		  var fldofspe = $rd(".form-item-fieldOfSpecialization .form-checkbox:checkbox:checked").length;
		  var degree = $rd("#edit-degree").val();
		  if(areaofment < 1){
			  e.preventDefault();
			$rd("#armtr_msg").remove();
			$rd(".form-item-areaofmentoring").after("<div id='armtr_msg' style='color:red;display: inline-block;padding-top: 10px !important;'>This field is required.</div>");  
			return false; 
			 
		  }else{
			  
			  $rd("#armtr_msg").remove(); 
			  
			  
			 
			 
		  }
		  if($rd("#mentee_dropdown_specialization_replace_1").parent().parent().css('display') == 'block' || $rd("#dropdown_specialization_replace_1").parent().parent().css('display') == 'block'){
		  if(fldofspe < 1){
			  e.preventDefault();
			$rd("#fldofspe_msg").remove();
			$rd(".form-item-fieldOfSpecialization").after("<div id='fldofspe_msg' style='color:red;display: inline-block;padding-top: 10px !important;'>This field is required.</div>");  
			return false;
			  
		  }else{
			  
			  
			$rd("#fldofspe_msg").remove();  
		  }
		  }
		  
		  if($rd("#edit-degree").length > 0){
			 if(degree ==''){
				$rd("#degree").remove();
				$rd("#edit-degree").after("<div id='degree' style='color:red;display: inline-block;padding-top: 10px !important;'>This field is required.</div>");  
				return false;	 
				 
			 }else{
				 
				 
				 $rd("#degree").remove();
			 }
             			 
			 
		  }
		  
		  
		  
		  
	  });
	  
	  <!------------------   Mentor Profile End  ------------------>
	  
	  
	  
	  
	   $rd('#mentee-profile-form #edit-submit').click(function(e){
		  //e.preventDefault();
		  var areaofment = $rd('.form-item-areaofmentoring .form-checkbox:checkbox:checked').length;
		  var fldofspe = $rd(".form-item-fieldOfSpecialization .form-checkbox:checkbox:checked").length;
		  var degree = $rd("#edit-degree").val();
		  if(areaofment < 1){
			  e.preventDefault();
			$rd("#armtr_msg").remove();
			$rd(".form-item-areaofmentoring").after("<div id='armtr_msg' style='color:red;display: inline-block;padding-top: 10px !important;'>This field is required.</div>");  
			return false; 
			 
		  }else{
			  
			  $rd("#armtr_msg").remove(); 
			  
			  
			 
			 
		  }
		  if($rd("#mentee_dropdown_specialization_replace_1").parent().parent().css('display') == 'block' || $rd("#dropdown_specialization_replace_1").parent().parent().css('display') == 'block' || $rd('#mentee_edit_dropdown_specialization_replace').parent().parent().css('display') == 'block'){
		  if(fldofspe < 1){
			  e.preventDefault();
			$rd("#fldofspe_msg").remove();
			$rd(".form-item-fieldOfSpecialization").after("<div id='fldofspe_msg' style='color:red;display: inline-block;padding-top: 10px !important;'>This field is required.</div>");  
			return false;
			  
		  }else{
			  
			  
			$rd("#fldofspe_msg").remove();  
		  }
		  }
		  
		  if($rd("#edit-degree").length > 0){
			 if(degree ==''){
				$rd("#degree").remove();
				$rd("#edit-degree").after("<div id='degree' style='color:red;display: inline-block;padding-top: 10px !important;'>This field is required.</div>");  
				return false;	 
				 
			 }else{
				 
				 
				 $rd("#degree").remove();
			 }
             			 
			 
		  }
		  
		  
		  
		  
	  });
	  
	  
	  
	  <!---------------  submit Mentor/mentee start   ------------>
	  
	  $rd("#edit-pre").click(function(e){
		   e.preventDefault();
		  $rd("#step_one").hide();
		  $rd("#step_two").show();
		  $rd("#step_three").hide();
		  $rd("#active_second").addClass('active');
		  $rd("#active_third").removeClass('active');
		  $rd("#edit-term-of-use").parent().hide();
		  
	  });
	  $rd("#step_first_bk").click(function(e){
		   e.preventDefault();
		  $rd("#step_one").show();
		  $rd("#step_two").hide();
		  $rd("#step_three").hide();
		  $rd("#active_first").addClass('active');
		  $rd("#active_second").removeClass('active');
		  $rd("#edit-term-of-use").parent().hide();
		  
	  });
	  
	  //$rd('.password-strength-text').text("Weak");
	  
		
		if($rd('#edit-transfer').css('display') == 'none')
			{
                 $rd('#edit-transfer').parent().parent().css('display','none');
			}
			$rd('#edit-mentee-type-transfer').click(function(){
				 $rd('#edit-college-name').parent().parent().css('display','block');
				 $rd('#edit-transfer').parent().parent().css('display','block');
				 $rd('#edit-highschool').parent().parent().css('display','none');
				 $rd('.form-item-yearOfIntendedTransfer').parent().parent().css('display','block');
				 $rd('.form-item-yearOfIntendedTransfer').css('display','block');
				 $rd('#edit-yearofschool').parent().parent().css('display','none');
			});
			$rd('#edit-mentee-type-highschool').click(function(){
				 $rd('#edit-college-name').parent().parent().css('display','none');
				 $rd('#edit-transfer').parent().parent().css('display','none');
				 $rd('#edit-highschool').parent().parent().css('display','block');
				 $rd('#edit-yearofschool').parent().parent().css('display','block');
			});
			/*$rd('#edit-mentee-type-transfer').click(function(){
				
				 $rd('#edit-transfer').parent().parent().css('display','block');
			});*/
			$rd('#edit-student').parent().parent().css('display','block');
			$rd('#edit-professional').parent().parent().css('display','block');
			$rd('#edit-m-type-professional').click(function(){
				 $rd('#edit-professional').parent().parent().css('display','block');
				 $rd('#edit-lastschoolattended').parent().parent().css({'display':'block','z-index':'9'});
				 $rd('#edit-student').parent().parent().css('display','none');
				 //$rd('#edit-lastschoolattended').parent().parent().css('display','none');
				 
			});
			$rd('#edit-m-type-student').click(function(){
				 $rd('#edit-professional').parent().parent().css('display','none');
				 $rd('#edit-student').parent().parent().css('display','block');
				 $rd('#edit-lastschoolattended').parent().parent().css('display','none');
			});
			if($rd('#edit-mentor-type-professional').prop('checked') == true){
				
				$rd('#edit-professional').parent().parent().css("cssText", "display: block !important;");
				$rd('#edit-professional').css('display','block');
				$rd('#edit-professional').parent().parent().addClass('showmentortype');
				

			}
			if($rd('#edit-m-type-student:checkbox:checked')){
				$rd('#edit-professional').parent().parent().css('display','none');
				
			}
		
		$rd(".tooltip_parent span").hover(function(){
			
			$rd(this).find('.skoolmentor-tooltip').css({"display":"block"},{"color":"#fff"});
		}, function(){
			
			$rd(this).find('.skoolmentor-tooltip').css("display",'none');
		});
		
		
		
		$rd('.panel-collapse').on('show.bs.collapse', function () {
	   $rd(this).siblings('.panel-heading').addClass('active');
	 });

	 $rd('.panel-collapse').on('hide.bs.collapse', function () {
	  $rd(this).siblings('.panel-heading').removeClass('active');
	 });
	  <!---   Save draft mentee step 1 -->
     $rd("#draft_set_one").click(function(e){	 
	 e.preventDefault();
		var fname = $rd("#edit-first-name").val();
		var lname = $rd("#edit-last-name").val();
		var gender = $rd("#edit-gender").val();
		
		var dob = $rd("#edit-bday-year").val()+'-'+ $rd("#edit-bday-month").val()+'-'+ $rd("#edit-bday-day").val() ;
		var zipocode = $rd("#edit-zipcode").val();
		var mobile = $rd("#edit-mobile").val();
		var parentmail = $rd("#edit-parent-mail").val();
		var skypeid = $rd("#edit-skype-id").val();
		$rd.ajax({
				    type: "GET",
				    url: "/mentee/draft",//Drupal.settings.mentoringcommon.ajaxUrl,
				    data: {fname: fname,lname: lname,gender: gender, dob: dob,zipocode: zipocode,mobile: mobile, parentmail: parentmail,skypeid: skypeid,step: 1 },
                    async: false,				   // serializes the form's elements.
				    success: function(data){
					   $rd("#save_draft").remove();
						$rd("#draft_set_one").parent().before("<div id='save_draft' style='color:#50f442;display: inline-block;padding-top: 5px !important;'>The profile is saved as draft.</div>");
						$rd("#save_draft").fadeOut(5000);
					} 
				 });
	 });
	 $rd("#draft_set_two").click(function(e){	 
		e.preventDefault();
		// var studentype = $rd("#edit-mentee-type-highschool").val();
		var studentype = $rd("input[name=mentee_type]:checked").val();
		
		if(studentype == 'highschool') {
			var schlnm = $rd("#edit-school-name").val();
			var yrofgraduation = $rd("#edit-yearofschool").val();
		} else if(studentype == 'transfer') {
			var clgname = $rd("#edit-college-name").val();
			var yearofintendedtransfer = $rd("#edit-yearofintendedtransfer").val();
		} 
		// console.log("test" + clgname);
		$rd.ajax({
			type: "GET",
			url: "/mentee/draft",//Drupal.settings.mentoringcommon.ajaxUrl,
			data: {studentype: studentype, schlnm: schlnm, yrofgraduation: yrofgraduation, clgname: clgname,yearofintendedtransfer: yearofintendedtransfer, step: 2},
			//async: false,				   // serializes the form's elements.
			success: function(data){
				// alert(data);
				console.log(data);
				$rd("#save_draft").remove();
				$rd("#draft_set_two").parent().before("<div id='save_draft' style='color:#50f442;display: inline-block;padding-top: 5px !important;'>The profile is saved as draft.</div>");
				$rd("#save_draft").fadeOut(5000);
			   
			} 
		 });
	 });
	 
	 $rd("#edit-draft-set-three").click(function(e){	 
	 e.preventDefault();
		var areaofmentoring = $rd("#edit-areaofmentoring").val();
		var val = [];
		
        $rd('.form-item-areaofmentoring .form-checkbox:checkbox:checked').each(function(i){
          val[i] = $rd(this).val();
        });
		//console.log(val);
		var fieldofstudy = $rd("#edit-fieldofstudy").val();
		var val2 = [];		
		
        $rd('.form-item-fieldOfSpecialization .form-checkbox:checkbox:checked').each(function(i){
          val2[i] = $rd(this).val();
        });
		var aboutme = $rd("#edit-mentoring-request").val() ;
		var yearofintendedtransfer = $rd("#edit-yearofintendedtransfer").val();
		$rd.ajax({
				    type: "GET",
				    url: "/mentee/draft",//Drupal.settings.mentoringcommon.ajaxUrl,
				    data: {areaofmentoring: val,fieldofstudy: fieldofstudy,fieldOfSpecialization: val2,aboutme: aboutme,step: 3},
                    // async: false,				   // serializes the form's elements.
				    success: function(data){
					   $rd("#save_draft").remove();
						$rd("#edit-draft-set-three").parent().before("<div id='save_draft' style='color:#50f442;display: inline-block;padding-top: 5px !important;'>The profile is saved as draft.</div>");
						$rd("#save_draft").fadeOut(5000);
					} 
				 });
	 });
	 
	 
	 <!---   Save draft mentee End up -->
	 
	 <!---   Save draft mentor step one start -->
	 $rd("#mentor_drft_one").click(function(e){	 
	 e.preventDefault();
		var fname = $rd("#edit-first-name").val();
		var lname = $rd("#edit-last-name").val();
		var gender = $rd("#edit-gender").val();
		var dob = $rd("#edit-bday-year").val()+'-'+ $rd("#edit-bday-month").val()+'-'+ $rd("#edit-bday-day").val() ;
		var zipocode = $rd("#edit-zipcode").val();
		var mobile = $rd("#edit-mobile").val();
		var accept_mentee = $rd("#edit-accept-mentee").val();
		var skypeid = $rd("#edit-skype-id").val();
		$rd.ajax({
				    type: "GET",
				    url: "/mentor/draft",//Drupal.settings.mentoringcommon.ajaxUrl,
				    data: {fname: fname,lname: lname,gender: gender, dob: dob,zipocode: zipocode,mobile: mobile, accept_mentee: accept_mentee,skypeid: skypeid,step: 1 },
                    async: false,				   // serializes the form's elements.
				    success: function(data){
					   $rd("#save_draft").remove();
						$rd("#mentor_drft_one").parent().before("<div id='save_draft' style='color:#50f442;display: inline-block;padding-top: 5px !important;'>The profile is saved as draft.</div>");
						$rd("#save_draft").fadeOut(5000);
					} 
				 });
	 });
	 
	 

     <!---   Save draft mentor step one End -->	 
	 
	 
	 <!---   Save draft mentor step two start -->
	 	 
	$rd("#mentor_drft_two").click(function(e){	 
		e.preventDefault();
		var mentortype = $rd("input[name=mentor_type]:checked").val();
		console.log(mentortype);
		if(mentortype == 'professional') {
			var employer = $rd("#edit-employer").val();
			var jobtitle = $rd("#edit-title").val();
			var yrsofexp = $rd("#edit-years-of-exp").val() ;
			var linkedinprofile = $rd("#edit-linkedinprofile").val();
			var lastschattd = $rd("#edit-last-school-attended").val();
			var yrofsch = $rd("#edit-year-of-school").val();
			var workmail = $rd("#edit-workemail").val();
			var confwrkmail = $rd("#edit-confirm-workemail").val();
			console.log("t" + employer+ "t"+ jobtitle + "t"+ yrsofexp + "t"+ linkedinprofile + "t"+ lastschattd + "t"+ yrofsch + "t"+ workmail + "t"+ confwrkmail);	
		} else if(mentortype == 'student') {
			var schattd = $rd("#edit-school-attending").val();
			var expectyrofsch = $rd("#edit-expected-year-of-school").val();
			var clgmail = $rd("#edit-collegeemail").val();
			var confclgmail = $rd("#edit-confirm-collegeemail").val();
			console.log("r" + schattd+ "r"+ expectyrofsch + "r"+ clgmail + "r"+ confclgmail);	
		} 
		var transhighsch = $rd("#edit-transfer-highschool").val();
		var highschname = $rd("#edit-highschoolname").val();
		var yrofhighsch = $rd("#edit-yearofhighschool").val();
		console.log("p" + transhighsch+ "p"+ highschname + "p"+ yrofhighsch);	
		
		$rd.ajax({
				    type: "GET",
				    url: "/mentor/draft",//Drupal.settings.mentoringcommon.ajaxUrl,
				    data: {mentortype: mentortype,employer: employer,jobtitle: jobtitle,yrsofexp: yrsofexp,linkedinprofile: linkedinprofile, lastschattd: lastschattd,yrofsch: yrofsch,workmail: workmail, confwrkmail: confwrkmail,schattd: schattd,expectyrofsch: expectyrofsch,clgmail: clgmail,confclgmail : confclgmail,transhighsch: transhighsch,highschname: highschname,yrofhighsch: yrofhighsch,step: 2},
                    // async: false,				   // serializes the form's elements.
				    success: function(data){
						console.log(data);
						$rd("#save_draft").remove();
						$rd("#mentor_drft_two").parent().before("<div id='save_draft' style='color:#50f442;display: inline-block;padding-top: 5px !important;'>The profile is saved as draft</div>");
						$rd("#save_draft").fadeOut(5000);
					   
					} 
				 });
	 });
	 

     <!---   Save draft mentor step two End -->	
	 
	 
	 
	 <!---   Save draft mentor step three start -->
	 
	 
	 $rd("#edit-mentor-drft-three").click(function(e){	 
	 e.preventDefault();
		var areaofmentoring = $rd("#edit-areaofmentoring").val();
		var val = [];
		
        $rd('.form-item-areaofmentoring .form-checkbox:checkbox:checked').each(function(i){
          val[i] = $rd(this).val();
        });
		//console.log(val);
		var degree = $rd("#edit-degree").val();
		var fieldofstudy = $rd("#edit-fieldofstudy").val();
		var val2 = [];		
		
        $rd('.form-item-fieldOfSpecialization .form-checkbox:checkbox:checked').each(function(i){
          val2[i] = $rd(this).val();
        });
		var aboutme = $rd("#edit-about-me").val();
		var othrclgaccpt = $rd("#edit-other-colleges-accepted-at").val() ;
		var fbprfoname = $rd("#edit-fb-uname").val() ;
		var accptresptime = $rd("#edit-response-time").val() ;
		var available = $rd("#edit-available-time").val() ;
		var volunteer = $rd("#edit-volunteer").val();
		var engagementmodl = $rd("input[name=engagement_model_with_mentee]:checked").val() ;
		
		
		
		$rd.ajax({
				    type: "GET",
				    url: "/mentor/draft",//Drupal.settings.mentoringcommon.ajaxUrl,
				    data: {areaofmentoring: val,degree: degree,fieldofstudy: fieldofstudy,fieldOfSpecialization: val2,aboutme: aboutme,othrclgaccpt: othrclgaccpt,fbprfoname: fbprfoname,accptresptime: accptresptime,available: available,volunteer: volunteer,engagementmodl: engagementmodl, step: 3},
                    //async: false,				   // serializes the form's elements.
				    success: function(data){
					   $rd("#save_draft").remove();
						$rd("#edit-mentor-drft-three").parent().before("<div id='save_draft' style='color:#50f442;display: inline-block;padding-top: 5px !important;'>The profile is saved as draft.</div>");
						$rd("#save_draft").fadeOut(5000);
					} 
				 });
	 });
	});
</script>
<script type="text/javascript">
	(function ($) {
			$(document).ready(function acceptButton() {
				$(".one_click").click(function(event){
					var href=$(this).attr('href');
					if(typeof href != 'undefined'){
						var r=confirm('Are you sure? Please choose the model of engagement carefully. Once your connection request is sent to the mentor, you will not be able to change the model of engagement.\nPress OK : to confirm.\nPress CANCEL: to select different engagement model.');
						if(r==true){
						   window.location = $(this).attr('href');
						   $(this).css("background-color","#B3B8BD");
						   $(this).removeAttr('href');
						   return true;
						} else{
							return false;
						}
					}
				});
			});
			$(".review_extended_history").click(function(){ var connetion_id = $(this).attr('id');
		      $('.session_extend_history-'+connetion_id).show();
		    });
		    $('.hover_bkgr_fricc').click(function(){
			  $('.hover_bkgr_fricc').hide();
		    });
		    $('.popupCloseButton').click(function(){
	 		  $('.hover_bkgr_fricc').hide();
            });
			$(".mentor_info").click(function(){ var connetion_id = $(this).attr('id');
		      $('.mentor_infos').show();
		    });
			$(".mentee_info").click(function(){ var connetion_id = $(this).attr('id');
		      $('.mentee_infos').show();
		    });
            if (window.location.hash && window.location.hash == '#_=_') {
           window.location.hash = '';
          }
			$("#subscriptionWindow").hide();
			//$("#subscriptionWindow").fadeIn(5000);
			$("#subscriptionWindow").find(".even").hide();
			$("#subscriptionWindow").find(".odd").hide();
			$("#subscriptionWindow").find(".views-row-first").show();
			$("#subscriptionWindow").find(".views-row-mid").show();
			$("#subscriptionWindow").find(".views-row-last").show();
			$("#subscriptionWindowClose").click(function(){ 
				$("#subscriptionWindow").fadeOut(1000);
			});	
	 })(jQuery);
	</script>
	<script type="text/javascript">

  (function ($) {
	  $('body').append('<div id="mask"></div>');
	 $("#user-pic-div").each(function(){
	      $(this).hover(function(){
		      var span = $(this).children("span");
		      span.show();
		      span.children("img").click(function(){
					$("#pic-upload-box").show();
					$("#mask").show();
			      });
		  },function(){
			  $(this).children("span").hide();
		  });
	   });
	   var stickyHeaderTop = $('.navbar-wrap').offset().top;
            //alert(stickyHeaderTop);
            $(window).scroll(function(){
				//alert($(window).scrollTop());
                    if( $(window).scrollTop() > stickyHeaderTop ) {
                        $('.navbar-wrap').addClass('fixed-menu');
                    }
                    else {
                        $('.navbar-wrap').removeClass('fixed-menu');
                    }
            });
	
  })(jQuery);	
      </script>
	  
	  <script>
window.onload = function($) { 
var no_mentee = document.getElementById("no_mentee").innerHTML;
var volunteer_mentors = document.getElementById("volunteer_mentors").innerHTML; 
var paid_mentors = document.getElementById("paid_mentors").innerHTML;
var no_nactivementor = document.getElementById("no_nactivementor").innerHTML;
var no_nactivementee = document.getElementById("no_nactivementee").innerHTML;
var chart = new CanvasJS.Chart("chartContainerone", {
	animationEnabled: true,
	title: {
		text: ""
	},
	data: [{
		type: "pie",
		startAngle: 240,
		yValueFormatString: "##0.\"\"",
		indexLabel: "{label} {y}",
		dataPoints: [
			{y: no_mentee, label: "Number of Mentees -"},
			{y: volunteer_mentors, label: "Volunteer Mentors -"},
			{y: paid_mentors, label: "Paid Mentors -"},
			{y: no_nactivementor, label: "Non-Activated Mentors -"},
			{y: no_nactivementee, label: "Non-Activated Mentees -"}
		]
	}]
});
chart.render();
var ondmd30min = document.getElementById("ondmd30min").innerHTML; 
var ondmdonehr = document.getElementById("ondmdonehr").innerHTML;
if(ondmdonehr == 0){ ondmdonehr = 0.00; } 
var thrmonth = document.getElementById("thrmonth").innerHTML;
if(thrmonth==0){ thrmonth =0.00}
var active_30_min_vol_conn = document.getElementById("active_30_min_vol_conn").innerHTML;
if(active_30_min_vol_conn==0){ active_30_min_vol_conn = 0.00;}
var activethirtyminpaidconn = document.getElementById("active_30_min_paid_conn").innerHTML;
var active_one_hr_vol_conn = document.getElementById("active_one_hr_vol_conn").innerHTML;
if(active_one_hr_vol_conn==0){ active_one_hr_vol_conn = 0.00;}
var active_one_hr_paid_conn = document.getElementById("active_one_hr_paid_conn").innerHTML;
if(active_one_hr_paid_conn == 0){ active_one_hr_paid_conn =0.00; }
var active_thr_moth_vol_conn = document.getElementById("active_thr_moth_vol_conn").innerHTML;
if(active_thr_moth_vol_conn ==0){ active_thr_moth_vol_conn =0.00}
var active_thr_moth_paid_conn = document.getElementById("active_thr_moth_paid_conn").innerHTML;
var paidconnexp = document.getElementById("paid_conn_exp").innerHTML;
var vol_conn_exp = document.getElementById("vol_conn_exp").innerHTML;
var vol_conn = document.getElementById("vol_conn").innerHTML;
if(vol_conn ==0){ vol_conn = 0.00; }
var paid_conn = document.getElementById("paid_conn").innerHTML;
if(paid_conn ==0){ paid_conn = 0.00; }
var vol_paid_conn_exp = document.getElementById("vol_paid_conn_exp").innerHTML;
if(vol_paid_conn_exp ==0){vol_paid_conn_exp = 0.00;}
console.log(active_one_hr_paid_conn);

var chart = new CanvasJS.Chart("chartContainertwo", {
	animationEnabled: true,
	title: {
		text: ""
	},
	data: [{
		type: "pie",
		startAngle: 240,
		yValueFormatString: "##0\"\"",
		indexLabel: "{label} {y}",
		dataPoints: [
			{y: ondmd30min, label: "On-Demand 30 Minutes-"},
			{y: ondmdonehr, label: "On-Demand 1 Hour-"},
			{y: activethirtyminpaidconn, label: "Active On-Demand 30 Minutes Paid-"},
			{y: active_one_hr_paid_conn, label: "Active On-Demand 1 Hour Paid-"},
			{y: active_one_hr_vol_conn, label: "Active On-Demand 1 Hour Volunteer-"},
			{y: active_30_min_vol_conn, label: "Active On-Demand 30 Minutes Volunteer-"},
			{y: thrmonth, label: "Three Months-"},
			{y: vol_conn, label: "Volunteer Connections -"},
			{y: paid_conn, label: "Paid Connections -"},
			{y: active_thr_moth_vol_conn, label: "Active Three Month Volunteer-"},
			{y: paidconnexp, label: "Paid Connections Expired -"},
            {y: vol_conn_exp, label: "Volunteer Connections - Expired -"}			
		]
	}]
});
chart.render();



}
</script>

<script type="text/javascript">
					(function ($) {
						$("div[id^=mentor-a]").hide();
						$("div[id^=mentee-a]").hide();
						$("div[id^=general-a]").hide();
						$("div[id^=grade-a]").hide();
						//$("#menteeqa").hide();
						//$("#mentorqa").hide();
						if($("#howItWorksDiv").is(":visible")){
								$("#howItWorksDiv").slideToggle(50);
								$("#howItWorksButton").toggleClass("bbg");
							}
						if($("#login-box").is(":visible")){
								$("#login-box").slideToggle(50);
								$("#signInForSkoolMentor").toggleClass("bbg");
						}
						$("#faqsButton").toggleClass("bbg");
						$("div[name^=mentor-arrow]").click(function() {
							
							//Fade in the Popup and add close button
							
							$("#mentorqa").slideToggle(50);
							if($("#mentor-image").attr("src") == "sites/all/modules/custom/faqs/menu-drop-bg-2.png"){
								$("#mentor-image").attr("src","sites/all/modules/custom/faqs/menu-drop-bg.png");
							}else{
								$("#mentor-image").attr("src","sites/all/modules/custom/faqs/menu-drop-bg-2.png");
							}
							return false;
						});
						$("div[name^=mentee-arrow]").click(function() {
							
							//Fade in the Popup and add close button
							
							$("#menteeqa").slideToggle(50);
							if($("#mentee-image").attr("src") == "sites/all/modules/custom/faqs/menu-drop-bg-2.png"){
								$("#mentee-image").attr("src","sites/all/modules/custom/faqs/menu-drop-bg.png");
							}else{
								$("#mentee-image").attr("src","sites/all/modules/custom/faqs/menu-drop-bg-2.png");
							}
							return false;
						});
						$("div[name^=general-arrow]").click(function() { 
							
							//Fade in the Popup and add close button
							
							$("#generalqa").slideToggle(50);
							if($("#general-image").attr("src") == "sites/all/modules/custom/faqs/menu-drop-bg-2.png"){
								$("#general-image").attr("src","sites/all/modules/custom/faqs/menu-drop-bg.png");
							}else{
								$("#general-image").attr("src","sites/all/modules/custom/faqs/menu-drop-bg-2.png");
							}
							return false;
						});
						$("div[name^=grade-arrow]").click(function() { 
							
							//Fade in the Popup and add close button
							
							$("#gradeqa").slideToggle(50);
							if($("#grade-image").attr("src") == "sites/all/modules/custom/faqs/menu-drop-bg-2.png"){
								$("#grade-image").attr("src","sites/all/modules/custom/faqs/menu-drop-bg.png");
							}else{
								$("#grade-image").attr("src","sites/all/modules/custom/faqs/menu-drop-bg-2.png");
							}
							return false;
						});
						$("div[id^=mentor-q]").click(function() {
							$(this).find("img").toggleClass("active");
							//Fade in the Popup and add close button
							var qId = this.getAttribute("id");
							var aId = "#"+qId.replace("-q","-a");
							$(aId).slideToggle(50);
			
							return false;
						});
						$("div[id^=mentee-q]").click(function() {
							$(this).find("img").toggleClass("active");
							//Fade in the Popup and add close button
							var qId = this.getAttribute("id");
							var aId = "#"+qId.replace("-q","-a");
							$(aId).slideToggle(50);
							
							return false;
						});
						$("div[id^=general-q]").click(function() {
                             //$("#generalqa .faqs-answer").slideUp();							
							 $(this).find("img").toggleClass("active");
							//Fade in the Popup and add close button
							
							var qId = this.getAttribute("id");
							var aId = "#"+qId.replace("-q","-a");
							$(aId).slideToggle(50);
							
			
							return false;
						});
						$("div[id^=grade-q]").click(function() {
                             //$("#generalqa .faqs-answer").slideUp();							
							 $(this).find("img").toggleClass("active");
							//Fade in the Popup and add close button
							
							var qId = this.getAttribute("id");
							var aId = "#"+qId.replace("-q","-a");
							$(aId).slideToggle(50);
							
			
							return false;
						});
					})(jQuery);
				</script>
				<script>
				function validatePhoneNumber(elementValue){
				  var phoneNumberPattern = /^\(?(\d{3})\)?[- ]?(\d{3})[- ]?(\d{4})$/;
				  return phoneNumberPattern.test(elementValue);
				}
			   function validateEmail($email) {
				  var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
				  return emailReg.test( $email );
				}
				function validateEmailedu($email) {
				  var emailReg = /^([\w-\.]+@([\w-]+\.)+[\edu-]{2,4})?$/;
				  return emailReg.test( $email );
				}
				function validatezipcode(zipcode){
					
					return /^\d{5}(-\d{4})?$/.test(zipcode);
					
				}
				function workemailprofessional($email){
				  var emailReg = /^([\w-.]+@(?!gmail\.com)(?!yahoo\.com)(?!hotmail\.com)([\w-]+.)+[\w-]{2,4})?$/;
				  return emailReg.test($email);	
					
				}
				</script>


<script src="../canvasjs.com/assets/script/canvasjs.min.js"></script>	 
	


</body>

<!-- Mirrored from www.skoolmentor.com/howitworks by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 04 Nov 2019 10:33:38 GMT -->
</html>
