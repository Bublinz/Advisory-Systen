 <?php
 require_once 'php/a_assets.php';
   require_once 'php/a_header.php';
  ?>



  <?php
if(isset($_POST['delete'])){ 
	$msg_id = filters('msg_id'); 
  
if(udi("$u personal_feed set std_rem_date='' $w msg_id='$msg_id'")){
		$success="Reminder Trashed";
	} else { 
		$error1="Reminder not delected";
	} 
}
  ?>



  <?php
if(isset($_POST['delete1'])){ 
	$rem_id = filters('rem_id'); 
  
if(udi("$u general_feed_reminder set rem_id='' $w msg_id='$msg_id'")){
		$success="Reminder Trashed";
	} else { 
		$error1="Reminder not delected";
	} 
}
  ?>

  
 
      <!-- Counts Section -->
      
     
      <!-- Updates Section -->
      <section class="mt-30px mb-30px">
        <div class="container-fluid">
          <div class="row">
            <div class="col-lg-4 col-md-12">
              <!-- General news feed widget         -->
              
              </div>
              <!-- General News feed End-->
            </div>


            <div class="col-lg-12 col-md-6">
              <!-- Personal news feed Widget-->
              <div id="daily-feeds" class="card updates daily-feeds">
                <div id="feeds-header" class="card-header d-flex justify-content-between align-items-center">
                  <h2 class="h5 display"><a data-toggle="collapse" data-parent="#daily-feeds" href="#feeds-box" aria-expanded="true" aria-controls="feeds-box">Messages from Mentees</a></h2>
                  <div class="right-column">
                    <?php  $percount1 = counts("$s personal_feed $w std_read_status='0' and msg_status='1'");?>
                    <div class="badge badge-primary">  <?php echo"$percount1";?> Unread SMS</div><a data-toggle="collapse" data-parent="#daily-feeds" href="#feeds-box" aria-expanded="true" aria-controls="feeds-box"><i class="fa fa-angle-down"></i></a>
                  </div>
                </div>
                <div id="feeds-box" role="tabpanel" class="collapse show">
                  <div class="feed-box">
                    <ul class="feed-elements list-unstyled" style="max-height: 500px;  overflow-y: auto;">
                      
                      <!-- List-->

                      <?php 
                      $perfeed = fetch("$s ment_message $w mm_read_status='0' and mm_status='1' order by mm_id desc");
                      if($perfeed<=0){
                        echo" <div  class='card-header d-flex justify-content-between align-items-center'>
                  <center><h2 class='h5 display'>You Have no Message !</h2></center>
                  </div>";
                      }else{
                        foreach ($perfeed as $p) {
                         
                         echo "<li class='clearfix'>
                        <div class='feed d-flex justify-content-between'>
                          <div class='feed-body d-flex justify-content-between'><a href='#' class='feed-profile'><img src='img/avatar-1.jpg' alt='person' class='img-fluid rounded-circle'></a>
                            <div class='content'><strong>$p->mm_date</strong> 
                              <div class='full-date'> </div>
                            </div>
                          </div>
                          <div class='date'>  </div>
                        </div>

                        <div class='message-card'> <small>$p->mm_message</small></div>";

                      
                          echo"
                          <form method='post' action='dash.php'>
                        <input type='hidden'   >
                        &nbsp;<button class='btn btn-xs btn-dark' name='read'><i class='fa fa-trash'> </i>Trash</button>
                        </form>
                       </li>";
                        
                      }
                        }
                      ?>



     <?php                 
//Persona Message reminder
if(isset($_POST['gremind'])){ 
  $rem_date = filters('reminder_date');
    $feed_id= filters('feed_id');
      $std_id= filters('std_id');
  if(udi("$i general_feed_reminder values('','$feed_id','$std_id','0','1','$rem_date','0','1','0') ")){

 }  
}

?>

     <?php                 
//Persona Message reminder
if(isset($_POST['remind'])){ 
  $rem_date = filters('reminder_date');
    $message_id= filters('message_id');
  if(udi("$u personal_feed set std_rem_date='$rem_date' where msg_id='$message_id'")){
 }  
}
if(isset($_POST['read'])){ 
   $message_id= filters('message_id');
  if(udi("$u personal_feed set std_read_status='1' where msg_id='$message_id'")){
   
  }   
}
?>
                       <?php?></span>
                     
                    </ul>
                  </div>
                </div>
              </div>
              <!-- Daily Feed Widget End-->
            </div>

            
          
        </div>
      </section>
     <?php require_once('php/a_footer.php');?>