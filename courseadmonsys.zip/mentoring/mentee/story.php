   <?php
 require_once 'php/a_assets.php';
   require_once 'php/a_header.php';
  ?>
 

 <!-- Breadcrumb-->
      <div class="breadcrumb-holder">
        <div class="container-fluid">
          <ul class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.html">Home</a></li>
            <li class="breadcrumb-item active">Success Story</li>
          </ul>
        </div>
      </div>
          <section class="forms">
        <div class="container-fluid">
          <!-- Page Header-->
          <header> 
            <h1 class="h3 display">Create a Success Story </h1>
          </header>
          <div class="row">
            <div class="col-lg-12">
              <div class="card">
                <div class="card-header d-flex align-items-center">
                  
                </div>
                <div class="card-body">
                  <p>Stories of your success can multivate others and help them realize the need to have a mentor in a particular area.</p>
                  <form>
                    <div class="form-group">
                      <label>What name would you want to publish this story with</label>
                      <input type="text" placeholder="Name" name="name" class="form-control">
                    </div>
                    <div class="form-group">       
                      <label>Narrate your story</label>
                      <textarea placeholder="Create your success story" rows="5" name="story" class="form-control"></textarea>
                    </div>
                    <div class="form-group">       
                      <input type="submit" value="Create" name="create_story" class="btn btn-primary">
                    </div>
                  </form>
                </div>
              </div>
            </div>
          
                  </form>
                </div>
              </div>
      </section>
       <?php require_once('php/a_footer.php');?>