   <?php
 require_once 'php/a_assets.php';
   require_once 'php/a_header.php';
  ?>
 

 <!-- Breadcrumb-->
      <div class="breadcrumb-holder">
        <div class="container-fluid">
          <ul class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.html">Home</a></li>
            <li class="breadcrumb-item active">Reminder      </li>
          </ul>
        </div>
      </div>
      <section>
        <div class="container-fluid">
          <!-- Page Header-->
          <header> 
            <h1 class="h3 display">Tables            </h1>
          </header>
          <div class="row">
            <div class="col-lg-6">
              <div class="card">
                <div class="card-header">
                  <h4>General Info Reminder</h4>
                </div>
                <div class="card-body">
                  <div class="table-responsive">
                    <table class="table">
                      <thead>
                        <tr>
                          <th>#</th>
                          <th>Reminder Date</th>
                          <th>Title</th>
                          <th>Message</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <th scope="row">1</th>
                          <td>###</td>
                          <td>###</td>
                          <td>###</td>
                        </tr>
                        <tr>
                          <th scope="row">2</th>
                          <td>###</td>
                          <td>###</td>
                          <td>###</td>
                        </tr>
                        <tr>
                          <th scope="row">3</th>
                          <td>###</td>
                          <td>###</td>
                          <td>###</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-lg-6">
              <div class="card">
                <div class="card-header">
                  <h4>Personal Info Reminder</h4>
                </div>
                <div class="card-body">
                  <div class="table-responsive">
                    <table class="table table-striped">
                      <thead>
                        <tr>
                          <th>#</th>
                          <th>Remider Date</th>
                          <th>Rating</th>
                          <th>Message</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <th scope="row">1</th>
                          <td>###</td>
                          <td>###</td>
                          <td>###</td>
                        </tr>
                        <tr>
                          <th scope="row">2</th>
                          <td>###</td>
                          <td>###</td>
                          <td>###</td>
                        </tr>
                        <tr>
                          <th scope="row">3</th>
                          <td>###</td>
                          <td>###</td>
                          <td>### </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
       <?php require_once('php/a_footer.php');?>