  <?php
 require_once 'php/a_assets.php';
   require_once 'php/a_header.php';
  ?>
 
 <?php
if(isset($_POST['request'])){
  $mentor_id = filters('mentor_id');
   $mentee_id = filters('mentee_id');
  if(udi("$i ment_connectivity values('','$mentor_id','$mentee_id','0',CURDATE())")){
	 
	} else { 
	
  } 
}

 ?>
     
      <!-- Updates Section -->
      <section class="mt-30px mb-30px">
        <div class="container-fluid">
          <div class="row">
            
             <div class="col-lg-12">
              <div class="card">
                <div class="card-header d-flex align-items-center">
                  <h4>Search for a Mentor</h4>
                </div>
                <div class="card-body">
                  <form class="form-inline">
                    <div class="form-group">
                      <label for="inlineFormInput" class="sr-only">Interest</label>
                      <input id="inlineFormInput" name="interest" type="text" placeholder="Area of Interest" class="mr-3 form-control">
                    </div>
                    <div class="form-group">
                      <label for="inlineFormInputGroup" class="sr-only">Study Field</label>
                      <input id="inlineFormInputGroup" type="text" name="field" placeholder="Study Field" class="mr-3 form-control form-control">
                    </div>
                    <div class="form-group">
                      <label for="inlineFormInputGroup" class="sr-only">Specialization</label>
                      <input id="inlineFormInputGroup" name="spec" type="text" placeholder="Specialization" class="mr-3 form-control form-control">
                      
                    </div>
                    <div class="form-group">
                      <input type="submit" value="Search" name="search" class="mr-3 btn btn-primary">
                    </div>
                    <div class="form-group">
                      <input type="submit" value="View  all Mentors" name="all_mentors" class="mr-3 btn btn-primary">
                    </div>
                  </form>
                </div>
              </div>
            </div>
            
            </div>
          </div>
      </section>

       <section class="statistics">
        <div class="container-fluid">
          <p style="text-align:center;font-size:18px;">Behold the best mentors of the world! Just Connect and be knowledge filled</p>
          <div class="row d-flex">

          <?php
         
        $disp = fetch("select * from mentor as m left join ment_connectivity as c on m.mentor_id=c.mm_mentor_id where m.accepting='yes' AND m.status='1' order by m.mentor_id desc ");
        //first looping starts here
          foreach($disp as $m){
             $mentee_id= get("mentee_id","$s mentee $w mentee_id= '".$_SESSION['id']."'");
             $mentor_id= get("mentor_id","$s mentor $w mentor_id= '$m->mm_mentor_id' ");
            echo"
        
            
             <div class='col-lg-4' style='margin-bottom: 10px;'>
              <!-- Monthly Usage-->
              <div class='card data-usage'>
                <h2 class='display h4'>$m->last_name, $m->first_name</h2>
                <div class='row d-flex align-items-center'>
                  <div class='col-sm-6'>
                    <div >
                      <img src='https://ptetutorials.com/images/user-profile.png' alt='image' style='width:100px; height:100px;'>
                    </div>
                  </div>
                  <div class='col-sm-6'><strong class='text-primary'>$m->city, $m->state</strong><small> 
                    
               
                  ";
                
                    if($m->mm_con_status=='0' AND $m->mm_mentee_id== $mentee_id){
                      echo "
                                       
                     <div class='card-body text-center'>
                  <button type='button' data-toggle='modal' data-target='#myModal' class='btn btn-warning'><i class='fa fa-chain'></i> Pending...</button>
                  <!-- Modal-->
                  <div id='myModal' tabindex='-1' role='dialog' aria-labelledby='exampleModalLabel' aria-hidden='true' class='modal fade text-left'>
                    <div role='document' class='modal-dialog'>
                      <div class='modal-content'>
                        <div class='modal-header'>
                          <h5 id='exampleModalLabel' class='modal-title'>Notification</h5>
                          <button type='button' data-dismiss='modal' aria-label='Close' class='close'><span aria-hidden='true'>×</span></button>
                        </div>
                        <div class='modal-body'>
                          <p style='font-size:23px;'>You have a pending connection with this mentor already!</p>
                         
                        </div>
                        <div class='modal-footer'>
                          <button type='button' data-dismiss='modal' class='btn btn-secondary'>Close</button>
                         
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                   ";}
                    elseif($m->mm_con_status=='1' AND $m->mm_mentee_id== $mentee_id ){

                       echo"
                      <span   class='btn btn-outline'><i class='fa fa-thumbs-up'></i> Connected</span>
                    
                        ";
                    }else{
                        echo "
                      <form method='post' action='dash.php'>
                  <input type='hidden' value='$m->mentor_id' name='mentor_id'>
                  <input type='hidden' value='$mentee_id' name='mentee_id'>
                    <button name='request' class='btn btn-primary'><i class='fa fa-chain'></i> Connect</button>
                    </form>";
                  }
                  
                
              echo"
                  </small><span>$m->study_field</span></div>
                </div>
                <p>$m->specialization | $m->interest_area</p>
              </div>
            </div>
            
           ";
          
        }
            ?>
            



            
          </div>
        </div>
      </section>
     <?php require_once('php/a_footer.php');?>