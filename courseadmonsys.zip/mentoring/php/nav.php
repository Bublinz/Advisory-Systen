
<?php
 require_once 'php/controller.php';
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" version="XHTML+RDFa 1.0" dir="ltr"
  xmlns:content="http://purl.org/rss/1.0/modules/content/"
  xmlns:dc="http://purl.org/dc/terms/"
  xmlns:foaf="http://xmlns.com/foaf/0.1/"
  xmlns:og="http://ogp.me/ns#"
  xmlns:rdfs="http://www.w3.org/2000/01/rdf-schema#"
  xmlns:sioc="http://rdfs.org/sioc/ns#"
  xmlns:sioct="http://rdfs.org/sioc/types#"
  xmlns:skos="http://www.w3.org/2004/02/skos/core#"
  xmlns:xsd="http://www.w3.org/2001/XMLSchema#">


<!-- Mirrored from www.skoolmentor.com/ by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 04 Nov 2019 10:26:55 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=utf-8" /><!-- /Added by HTTrack -->
<head profile="http://www.w3.org/1999/xhtml/vocab">
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />

<meta name="generator" content="Drupal 7 (https://www.drupal.org)" />
<link rel="canonical" href="index.php" />
<link rel="shortlink" href="index.php" />
  <title>Welcome | Mentoring Git</title>
   
  
  <style type="text/css" media="all">
@import url("https://www.skoolmentor.com/modules/system/system.base.css?q08noi");
@import url("https://www.skoolmentor.com/modules/system/system.menus.css?q08noi");
@import url("https://www.skoolmentor.com/modules/system/system.messages.css?q08noi");
@import url("https://www.skoolmentor.com/modules/system/system.theme.css?q08noi");
</style>
<style type="text/css" media="screen">
@import url("sites/all/modules/contrib/qtip/library/jquery.qtip15ff.css?q08noi");
@import url("sites/all/modules/contrib/qtip/css/qtip15ff.css?q08noi");
@import url("sites/all/libraries/owl-carousel/owl.carousel15ff.css?q08noi");
@import url("sites/all/libraries/owl-carousel/owl.theme15ff.css?q08noi");
@import url("sites/all/libraries/owl-carousel/owl.transitions15ff.css?q08noi");
</style>
<style type="text/css" media="all">
@import url("https://www.skoolmentor.com/modules/comment/comment.css?q08noi");
@import url("sites/all/modules/contrib/date/date_api/date15ff.css?q08noi");
@import url("sites/all/modules/contrib/date/date_popup/themes/datepicker.1.715ff.css?q08noi");
@import url("https://www.skoolmentor.com/modules/field/theme/field.css?q08noi");
</style>
<style type="text/css" media="screen">
@import url("sites/all/modules/contrib/invite/modules/invite_by_email/css/invite_by_email15ff.css?q08noi");
</style>
<style type="text/css" media="all">
@import url("https://www.skoolmentor.com/modules/node/node.css?q08noi");
@import url("https://www.skoolmentor.com/modules/search/search.css?q08noi");
@import url("sites/all/modules/contrib/ubercart/uc_order/uc_order15ff.css?q08noi");
@import url("sites/all/modules/contrib/ubercart/uc_product/uc_product15ff.css?q08noi");
@import url("sites/all/modules/contrib/ubercart/uc_store/uc_store15ff.css?q08noi");
@import url("sites/all/modules/contrib/views/css/views15ff.css?q08noi");
</style>
<style type="text/css" media="all">
@import url("sites/all/modules/contrib/colorbox/styles/default/colorbox_style15ff.css?q08noi");
@import url("sites/all/modules/contrib/ctools/css/ctools15ff.css?q08noi");
@import url("sites/all/modules/contrib/hybridauth/plugins/icon_pack/hybridauth_32/hybridauth_3215ff.css?q08noi");
@import url("sites/all/modules/contrib/hybridauth/css/hybridauth15ff.css?q08noi");
@import url("sites/all/modules/contrib/hybridauth/css/hybridauth.modal15ff.css?q08noi");
@import url("sites/all/modules/contrib/fivestar/css/fivestar15ff.css?q08noi");
@import url("sites/all/modules/contrib/fivestar/widgets/oxygen/oxygen15ff.css?q08noi");
</style>
<link type="text/css" rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans:400,400i,600,600i,700" media="all" />
<style type="text/css" media="all">
@import url("sites/all/modules/contrib/feedback_simple/feedback_simple15ff.css?q08noi");
@import url("sites/all/libraries/superfish/css/superfish15ff.css?q08noi");
@import url("sites/all/libraries/superfish/css/superfish-smallscreen15ff.css?q08noi");
</style>
<style type="text/css" media="all">
@import url("sites/all/themes/skoolmentor/css/bootstrap.min15ff.css?q08noi");
@import url("sites/all/themes/skoolmentor/css/style15ff.css?q08noi");
@import url("sites/all/themes/skoolmentor/css/slick15ff.css?q08noi");
@import url("sites/all/themes/skoolmentor/css/ie15ff.css?q08noi");
@import url("sites/all/themes/skoolmentor/css/ie615ff.css?q08noi");
@import url("sites/all/themes/skoolmentor/font-awesome/css/font-awesome.min15ff.css?q08noi");
</style>
  <script type="text/javascript" src="sites/all/modules/contrib/jquery_update/replace/jquery/1.10/jquery.min468f.js?v=1.10.2"></script>
<script type="text/javascript" src="https://www.skoolmentor.com/misc/jquery.once.js?v=1.2"></script>
<script type="text/javascript" src="https://www.skoolmentor.com/misc/drupal.js?q08noi"></script>
<script type="text/javascript" src="sites/all/modules/contrib/qtip/library/jquery.qtipa6f1.js?v=2.0.0pre"></script>
<script type="text/javascript" src="sites/all/modules/contrib/qtip/js/qtipa6f1.js?v=2.0.0pre"></script>
<script type="text/javascript" src="sites/all/modules/contrib/jquery_update/replace/ui/external/jquery.cookie1683.js?v=67fb34f6a866c40d0570"></script>
<script type="text/javascript" src="sites/all/modules/contrib/jquery_update/replace/misc/jquery.form.min97e5.js?v=2.69"></script>
<script type="text/javascript" src="https://www.skoolmentor.com/misc/ajax.js?v=7.59"></script>
<script type="text/javascript" src="sites/all/modules/contrib/jquery_update/js/jquery_update241d.js?v=0.0.1"></script>
<script type="text/javascript" src="sites/all/modules/admin_menu/admin_devel/admin_devel15ff.js?q08noi"></script>
<script type="text/javascript" src="sites/all/modules/custom/skoolmentor_schoolregister/js/skoolmentor_schoolregister15ff.js?q08noi"></script>
<script type="text/javascript" src="sites/all/modules/contrib/colorbox/js/colorbox15ff.js?q08noi"></script>
<script type="text/javascript" src="sites/all/modules/contrib/colorbox/styles/default/colorbox_style15ff.js?q08noi"></script>
<script type="text/javascript" src="sites/all/modules/contrib/google_analytics/googleanalytics15ff.js?q08noi"></script>
<script type="text/javascript">
<!--//--><![CDATA[//><!--
(function(i,s,o,g,r,a,m){i["GoogleAnalyticsObject"]=r;i[r]=i[r]||function(){(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)})(window,document,"script","../www.google-analytics.com/analytics.js","ga");ga("create", "UA-96598213-1", {"cookieDomain":"auto"});ga("set", "anonymizeIp", true);ga("send", "pageview");
//--><!]]>
</script>
<script type="text/javascript" src="sites/all/modules/custom/mentoringcommon/js/custom-file-input15ff.php?q08noi"></script>
<script type="text/javascript" src="sites/all/modules/custom/mentoringcommon/js/jquery.validate15ff.js?q08noi"></script>
<script type="text/javascript" src="../www.google.com/recaptcha/api.js"></script>
<script type="text/javascript" src="https://www.skoolmentor.com/misc/progress.js?v=7.59"></script>
<script type="text/javascript" src="sites/all/modules/contrib/hybridauth/js/hybridauth.modal15ff.js?q08noi"></script>
<script type="text/javascript" src="https://www.skoolmentor.com/misc/autocomplete.js?v=7.59"></script>
<script type="text/javascript" src="sites/all/modules/contrib/hybridauth/js/hybridauth.onclick15ff.js?q08noi"></script>
<script type="text/javascript" src="sites/all/libraries/superfish/jquery.hoverIntent.minified15ff.js?q08noi"></script>
<script type="text/javascript" src="sites/all/libraries/superfish/sftouchscreen15ff.js?q08noi"></script>
<script type="text/javascript" src="sites/all/libraries/superfish/sfsmallscreen15ff.js?q08noi"></script>
<script type="text/javascript" src="sites/all/libraries/superfish/supposition15ff.js?q08noi"></script>
<script type="text/javascript" src="sites/all/libraries/superfish/superfish15ff.js?q08noi"></script>
<script type="text/javascript" src="sites/all/libraries/superfish/supersubs15ff.js?q08noi"></script>
<script type="text/javascript" src="sites/all/modules/contrib/superfish/superfish15ff.js?q08noi"></script>
<script type="text/javascript" src="sites/all/themes/skoolmentor/js/bootstrap.min15ff.js?q08noi"></script>
<script type="text/javascript" src="sites/all/themes/skoolmentor/js/slick.min15ff.js?q08noi"></script>
<script type="text/javascript" src="sites/all/themes/skoolmentor/js/html5lightbox15ff.js?q08noi"></script>
<script type="text/javascript" src="sites/all/themes/skoolmentor/js/jquery.smooth-scroll15ff.js?q08noi"></script>
<script type="text/javascript">
<!--//--><![CDATA[//><!--
jQuery.extend(Drupal.settings, {"basePath":"\/","pathPrefix":"","ajaxPageState":{"theme":"skoolmentor","theme_token":"A_F_DuGuBjseI4UFJMPqtKudvByDF8itn-L2ywEpV7A","jquery_version":"1.10","js":{"sites\/all\/libraries\/owl-carousel\/owl.carousel.min.js":1,"sites\/all\/modules\/contrib\/owlcarousel\/includes\/js\/owlcarousel.settings.js":1,"sites\/all\/modules\/contrib\/jquery_update\/replace\/jquery\/1.10\/jquery.min.js":1,"misc\/jquery.once.js":1,"misc\/drupal.js":1,"sites\/all\/modules\/contrib\/qtip\/library\/jquery.qtip.js":1,"sites\/all\/modules\/contrib\/qtip\/js\/qtip.js":1,"sites\/all\/modules\/contrib\/jquery_update\/replace\/ui\/external\/jquery.cookie.js":1,"sites\/all\/modules\/contrib\/jquery_update\/replace\/misc\/jquery.form.min.js":1,"misc\/ajax.js":1,"sites\/all\/modules\/contrib\/jquery_update\/js\/jquery_update.js":1,"sites\/all\/modules\/admin_menu\/admin_devel\/admin_devel.js":1,"sites\/all\/modules\/custom\/skoolmentor_schoolregister\/js\/skoolmentor_schoolregister.js":1,"sites\/all\/modules\/contrib\/colorbox\/js\/colorbox.js":1,"sites\/all\/modules\/contrib\/colorbox\/styles\/default\/colorbox_style.js":1,"sites\/all\/modules\/contrib\/google_analytics\/googleanalytics.js":1,"0":1,"sites\/all\/modules\/custom\/mentoringcommon\/js\/custom-file-input.js":1,"sites\/all\/modules\/custom\/mentoringcommon\/js\/jquery.validate.js":1,"https:\/\/www.google.com\/recaptcha\/api.js":1,"misc\/progress.js":1,"sites\/all\/modules\/contrib\/hybridauth\/js\/hybridauth.modal.js":1,"misc\/autocomplete.js":1,"sites\/all\/modules\/contrib\/hybridauth\/js\/hybridauth.onclick.js":1,"sites\/all\/libraries\/superfish\/jquery.hoverIntent.minified.js":1,"sites\/all\/libraries\/superfish\/sftouchscreen.js":1,"sites\/all\/libraries\/superfish\/sfsmallscreen.js":1,"sites\/all\/libraries\/superfish\/supposition.js":1,"sites\/all\/libraries\/superfish\/superfish.js":1,"sites\/all\/libraries\/superfish\/supersubs.js":1,"sites\/all\/modules\/contrib\/superfish\/superfish.js":1,"sites\/all\/themes\/skoolmentor\/js\/bootstrap.min.js":1,"sites\/all\/themes\/skoolmentor\/js\/slick.min.js":1,"sites\/all\/themes\/skoolmentor\/js\/html5lightbox.js":1,"sites\/all\/themes\/skoolmentor\/js\/jquery.smooth-scroll.js":1},"css":{"modules\/system\/system.base.css":1,"modules\/system\/system.menus.css":1,"modules\/system\/system.messages.css":1,"modules\/system\/system.theme.css":1,"sites\/all\/modules\/contrib\/qtip\/library\/jquery.qtip.css":1,"sites\/all\/modules\/contrib\/qtip\/css\/qtip.css":1,"sites\/all\/libraries\/owl-carousel\/owl.carousel.css":1,"sites\/all\/libraries\/owl-carousel\/owl.theme.css":1,"sites\/all\/libraries\/owl-carousel\/owl.transitions.css":1,"modules\/comment\/comment.css":1,"sites\/all\/modules\/contrib\/date\/date_api\/date.css":1,"sites\/all\/modules\/contrib\/date\/date_popup\/themes\/datepicker.1.7.css":1,"modules\/field\/theme\/field.css":1,"sites\/all\/modules\/contrib\/invite\/modules\/invite_by_email\/css\/invite_by_email.css":1,"modules\/node\/node.css":1,"modules\/search\/search.css":1,"sites\/all\/modules\/contrib\/ubercart\/uc_order\/uc_order.css":1,"sites\/all\/modules\/contrib\/ubercart\/uc_product\/uc_product.css":1,"sites\/all\/modules\/contrib\/ubercart\/uc_store\/uc_store.css":1,"sites\/all\/modules\/contrib\/views\/css\/views.css":1,"sites\/all\/modules\/contrib\/colorbox\/styles\/default\/colorbox_style.css":1,"sites\/all\/modules\/contrib\/ctools\/css\/ctools.css":1,"sites\/all\/modules\/contrib\/hybridauth\/plugins\/icon_pack\/hybridauth_32\/hybridauth_32.css":1,"sites\/all\/modules\/contrib\/hybridauth\/css\/hybridauth.css":1,"sites\/all\/modules\/contrib\/hybridauth\/css\/hybridauth.modal.css":1,"sites\/all\/modules\/contrib\/fivestar\/css\/fivestar.css":1,"sites\/all\/modules\/contrib\/fivestar\/widgets\/oxygen\/oxygen.css":1,"https:\/\/fonts.googleapis.com\/css?family=Open+Sans:400,400i,600,600i,700":1,"sites\/all\/modules\/contrib\/feedback_simple\/feedback_simple.css":1,"sites\/all\/libraries\/superfish\/css\/superfish.css":1,"sites\/all\/libraries\/superfish\/css\/superfish-smallscreen.css":1,"sites\/all\/themes\/skoolmentor\/css\/bootstrap.min.css":1,"sites\/all\/themes\/skoolmentor\/css\/style.css":1,"sites\/all\/themes\/skoolmentor\/css\/slick.css":1,"sites\/all\/themes\/skoolmentor\/css\/ie.css":1,"sites\/all\/themes\/skoolmentor\/css\/ie6.css":1,"sites\/all\/themes\/skoolmentor\/font-awesome\/css\/font-awesome.min.css":1}},"colorbox":{"opacity":"0.85","current":"{current} of {total}","previous":"\u00ab Prev","next":"Next \u00bb","close":"Close","maxWidth":"98%","maxHeight":"98%","fixed":true,"mobiledetect":true,"mobiledevicewidth":"480px"},"qtip":{"target_position":"bottom_center","tooltip_position":"top_center","show_speech_bubble_tip":1,"show_speech_bubble_tip_side":1,"speech_bubble_size":"12","show_speech_bubble_tip_solid":0,"show_shadow":0,"rounded_corners":1,"color":"ui-tooltip-jtools","custom_color":"","show_event_type":"mouseenter","hide_event_type":"mouseleave","show_webform_descriptions":0,"additional_elements":""},"owlcarousel":{"owl-carousel-block11":{"settings":{"items":1,"itemsDesktop":["1199",1],"itemsDesktopSmall":["979",1],"itemsTablet":["768",1],"itemsTabletSmall":["0",0],"itemsMobile":["479",1],"singleItem":false,"itemsScaleUp":false,"slideSpeed":200,"paginationSpeed":800,"rewindSpeed":1000,"autoPlay":"5000","stopOnHover":false,"navigation":true,"navigationText":["",""],"rewindNav":true,"scrollPerPage":true,"pagination":true,"paginationNumbers":false,"responsive":true,"responsiveRefreshRate":200,"baseClass":"owl-carousel","theme":"owl-theme","lazyLoad":false,"lazyFollow":true,"lazyEffect":"fadeIn","autoHeight":false,"jsonPath":false,"jsonSuccess":false,"dragBeforeAnimFinish":true,"mouseDrag":true,"touchDrag":true,"addClassActive":false,"transitionStyle":false},"views":{"ajax_pagination":null}}},"googleanalytics":{"trackOutbound":1,"trackMailto":1,"trackDownload":1,"trackDownloadExtensions":"7z|aac|arc|arj|asf|asx|avi|bin|csv|doc(x|m)?|dot(x|m)?|exe|flv|gif|gz|gzip|hqx|jar|jpe?g|js|mp(2|3|4|e?g)|mov(ie)?|msi|msp|pdf|phps|png|ppt(x|m)?|pot(x|m)?|pps(x|m)?|ppam|sld(x|m)?|thmx|qtm?|ra(m|r)?|sea|sit|tar|tgz|torrent|txt|wav|wma|wmv|wpd|xls(x|m|b)?|xlt(x|m)|xlam|xml|z|zip","trackColorbox":1},"urlIsAjaxTrusted":{"\/":true,"\/system\/ajax":true},"superfish":{"1":{"id":"1","sf":{"animation":{"opacity":"show","height":"show"},"speed":"fast"},"plugins":{"touchscreen":{"behaviour":"1","mode":"window_width","breakpointUnit":"px"},"smallscreen":{"mode":"window_width","breakpoint":320,"breakpointUnit":"px","title":"Main menu"},"supposition":true,"supersubs":true}}},"ajax":{"edit-usertype-mentee":{"event":"change","callback":"signup_type_ajax_callback","progress":{"message":""},"wrapper":"signup_type_dropdown_replace","url":"\/system\/ajax","submit":{"_triggering_element_name":"usertype"}},"edit-usertype-mentor":{"event":"change","callback":"signup_type_ajax_callback","progress":{"message":""},"wrapper":"signup_type_dropdown_replace","url":"\/system\/ajax","submit":{"_triggering_element_name":"usertype"}}}});
//--><!]]>
</script>
  
 
		
	

		
	

</head>
<body>
    <header id="top">
     <div class="navbar-wrap">
	<div class="container">
	<nav class="navbar navbar-default main-menu" >
		    <div class="navbar-header">
		    	<div class="mob-menu-bg">
		        <button type="button" data-target="#navbarCollapse" data-toggle="collapse" class="navbar-toggle">
		            <span class="sr-only">Toggle navigation</span>
		            <span class="icon-bar"></span>
		            <span class="icon-bar"></span>
		            <span class="icon-bar"></span>
		        </button>
		        <!--<ul class="btn-mob">
		        	<li class="btn-signin"><a href="#">Sign in</a></li>
		        	<li class="btn-signin"><a href="#" >Register</a></li>
		        </ul>-->
		    	</div>
				 				 <a href="index.php" title="Home" rel="home" id="logo" class="navbar-brand">
				
				  </a>
						        <!---   Code comment to make it dynmaic logo 
				<a href="index.php" ><img src="sites/all/themes/skoolmentor/images/logo.png" class="img-responsive"></a>-->
			
		    </div>
		    <div id="navbarCollapse" class="collapse navbar-collapse">
					  <div class="region region-header">
    <div id="block-superfish-1" class="block block-superfish">

  
  <div class="content">
    <ul  id="superfish-1" class="menu sf-menu sf-main-menu sf-horizontal sf-style-none sf-total-items-7 sf-parent-items-2 sf-single-items-5 nav navbar-nav"><li id="menu-2600-1" class="first odd sf-item-1 sf-depth-1 sf-total-children-4 sf-parent-children-0 sf-single-children-4 menuparent"><a href="index.php" title="" class="sf-depth-1 menuparent nolink">Home</a></li><li id="menu-2249-1" class="middle even sf-item-2 sf-depth-1 sf-no-children"><a href="testimonials.php" title="" class="sf-depth-1">Success Stories</a></li><li id="menu-218-1" class="middle odd sf-item-3 sf-depth-1 sf-no-children"><a href="howitworks.php" class="sf-depth-1">How It Works</a></li><li id="menu-334-1" class="middle odd sf-item-5 sf-depth-1 sf-no-children"><a href="../index.php" title="" class="sf-depth-1"> Main Page</a></li><li id="menu-1146-1" class="middle even sf-item-6 sf-depth-1 sf-no-children"><a href="javascript:void(0)" title="" class="sf-depth-1 nolink">Sign-in</a></li><li id="menu-2602-1" class="last odd sf-item-7 sf-depth-1 sf-no-children"><a href="javascript:void(0)" title="" class="sf-depth-1 nolink">Register</a></li></ul>  </div>
</div>
  </div>

					
							       
		    </div>
		</nav>
				