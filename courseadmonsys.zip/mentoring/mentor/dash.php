  <?php
 require_once 'php/a_assets.php';
   require_once 'php/a_header.php';
  ?>
 
     
     
      <!-- Updates Section -->
      <section class="mt-30px mb-30px">
        <div class="container-fluid">
          <div class="row">
            <div class="col-lg-12 col-md-12">
              <!-- General news feed widget         -->
              <div id="new-updates" class="card updates recent-updated">
                <div id="updates-header" class="card-header d-flex justify-content-between align-items-center">
                  <h2 class="h5 display"><a data-toggle="collapse" data-parent="#new-updates" href="#updates-box" aria-expanded="true" aria-controls="updates-box">What mentees are saying about this platform</a></h2><a data-toggle="collapse" data-parent="#new-updates" href="#updates-box" aria-expanded="true" aria-controls="updates-box"><i class="fa fa-angle-down"></i></a>
                </div>
                <div id="updates-box" role="tabpanel" class="collapse show">
                  <ul class="news list-unstyled"  style="max-height: 500px;  overflow-y: auto;" >
                    <!-- Item-->

                    <?php 
                    $story =fetch("select suc.*, men.* from success_story as suc left join mentee as men on suc.mentee_id=men.mentee_id where suc.suc_status='1' order by suc_id DESC");
                    if($story<=0){
                       echo" <div  class='card-header d-flex justify-content-between align-items-center'>
                  <center><h2 class='h5 display'>No story yet!</h2></center>
                  </div>"; }
                  else{
                    foreach ($story as $g) {
                      echo "

                      <li class='d-flex justify-content-between'> 
                      <div class='left-col d-flex'>
                        <div class='icon'><i class='icon-rss-feed'></i></div>
                        <div class='title'><strong>$g->last_name,$g->first_name</strong>
                          <p>$g->suc_story</p>
                          
                        </div>

                      </div>
                      <div class='right-col text-right' style='width:45px; font-size:10px;'>
                        <div class='update-date'>$g->suc_date</div>

                      </div>

                    </li>

                      ";
                    }
                  }
                    
                    ?>
                </ul>
                </div>
              </div>
             
            </div>
          </div>
        </div>
      </section>
     <?php require_once('php/a_footer.php');?>