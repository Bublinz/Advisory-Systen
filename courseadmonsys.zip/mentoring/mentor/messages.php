    <?php
    require_once ('php/a_assets.php'); 
        require_once ('php/a_header.php'); 
?>

     <link rel="stylesheet" href="css/sms.css">

      <!-- Breadcrumb-->
      <div class="breadcrumb-holder">
        <div class="container-fluid">
          <ul class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.html">Home</a></li>
            <li class="breadcrumb-item active">Smart Chat </li>
          </ul>
        </div>
      </div>
       <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<!------ Include the above in your HEAD tag ---------->


<html>
<head>

<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css" type="text/css" rel="stylesheet"

</head>
<body>
<div class="container">
<h3 class=" text-center">Messaging</h3>
<div class="messaging">
      <div class="inbox_msg">
        <div class="inbox_people">
          <div class="headind_srch">
            
            <div class="srch_bar">
              <div class="stylish-input-group">
                <input type="text" class="search-bar"  placeholder="Search by name " >
                <span class="input-group-addon">
                
                </span> </div>
            </div>
          </div>
          <div class="inbox_chat">
            
 
              <?php 
                      $gstd = fetch("SELECT men.*, con.*  FROM ment_connectivity as con LEFT JOIN mentee as men ON con.mm_mentee_id=men.mentee_id $w con.mm_mentor_id = '".$_SESSION['id']."' AND con.mm_con_status='1' ");
                      if ($gstd<=0){
                        echo "<pYou have no connected mentee yet!</p>";
                      }else{
                         
                        foreach($gstd as $r){
                          
                          echo "
            <form method='post' action='messages.php#sms'>
            <div class='chat_list active_chat'>
              <div class='chat_people'>
                <div class='chat_img'> <img src='https://ptetutorials.com/images/user-profile.png' alt='sunil'> </div>
                <div class='chat_ib'>
                <input type='hidden' value='$r->mentee_id' name='mentee_id'>
                
                  <h5>$r->last_name, $r->first_name</span></h5>
                  <span>$r->mobile</span>
                    <button type='submit' name='next'><i class='fa fa-send'></i></button>
                </div>
              </div>
            </div>
            </form>";
                        }
                      }
                      ?>



          </div>
        </div>
        <div class="mesgs" id="sms">
          <div class="msg_history">




                 <?php
                   if(isset($_POST['next'])){ 
                    $mentee_id = filters('mentee_id');
                   $show = fetch("SELECT sms.*, men.* FROM ment_message as sms LEFT JOIN mentee as men ON sms.mentee_id = men.mentee_id $w sms.mm_status='1' AND sms.mentee_id ='$mentee_id' ORDER BY sms.mm_id ASC");

                      foreach($show as $r){
                          
                          echo " 
                          <div class='incoming_msg'>
            <div class='incoming_msg_img'> <img src='https://ptetutorials.com/images/user-profile.png' alt='sunil'> </div>
              <div class='received_msg'>
                <div class='received_withd_msg'>
                  <p>$r->mm_message</p>
                  <span class='time_date'> $r->mm_date</span></div>
              </div>
            </div>
                          
                          ";
                      }

                  
            echo "
             <form method='post' action='messages.php#sms'>
          </div>
          <div class='type_msg'>
            <div class='input_msg_write'>
              <input type='text' class='write_msg' name='sms' placeholder='Type a message' required/>
              <input type='hidden'  name='mentee_id' value='$mentee_id' />
              <button class='btn btn-primary' name='new_sms' type='submit'><i class='fa fa-paper-plane-o' aria-hidden='true'></i> SEND</button>
            </div>
          </div>
        </div>
      </div>
      </form>
      ";
        
       }
    ?>


                <?php
                   if(isset($_POST['new_sms'])){ 
                    $mentee_id = filters('mentee_id');
                    $sms = filters('sms');
                    $mentor_id =	$_SESSION['id'] ;
                    if(udi("$i ment_message (mm_id, mm_message, mentor_id, mentee_id, mm_read_status, mm_date,mm_status ) values('','$sms','$mentor_id','$mentee_id','0', CURDATE(),'1')")){
	    
      }else{
        echo "something went wrong";
      }
    }
    ?>

    </div></div>
    </body>
    </html>

     <?php
         require_once ('php/a_footer.php'); ?>

  <script>
    	$(document).ready(function(){
$('#action_menu_btn').click(function(){
	$('.action_menu').toggle();
});
	});
  </script>