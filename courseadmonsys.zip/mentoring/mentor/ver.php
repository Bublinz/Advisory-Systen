<?php 
     require_once 'php/database.php';  
  require_once 'php/controller.php';  
?>
<?php error_reporting('0') ?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Mentoring System</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="all,follow">
    <!-- Bootstrap CSS-->
    <link rel="stylesheet" href="vendor/bootstrap/css/bootstrap.min.css">
    <!-- Font Awesome CSS-->
    <link rel="stylesheet" href="vendor/font-awesome/css/font-awesome.min.css">
    <!-- Fontastic Custom icon font-->
    <link rel="stylesheet" href="css/fontastic.css">
    <!-- Google fonts - Roboto -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700">
    <!-- jQuery Circle-->
    <link rel="stylesheet" href="css/grasp_mobile_progress_circle-1.0.0.min.css">
    <!-- Custom Scrollbar-->
    <link rel="stylesheet" href="vendor/malihu-custom-scrollbar-plugin/jquery.mCustomScrollbar.css">
    <!-- theme stylesheet-->
    <link rel="stylesheet" href="css/style.default.css" id="theme-stylesheet">
    <!-- Custom stylesheet - for your changes-->
    <link rel="stylesheet" href="css/custom.css">
    <!-- Favicon-->
    <link rel="shortcut icon" href="img/favicon.ico">
    <!-- Tweaks for older IEs--><!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->
        <style type="text/css">
        
        </style>
  </head>
  <body>
    <div class="page login-page">
      <div class="container" style="max-width: 100%;">
        <div class="form-outer text-center d-flex align-items-center">
          <div class="form-inner">
            <div class="logo text-uppercase"><span>Let's Get</span><strong class="text-primary">Started</strong></div>
            <p>Please fill the form below to accecc your account.</p><hr>

            <form class="text-left form-validate" method="post" action="register.php">
             <center style="font-weight: bold; font-size: 20px;"> <p style="color: yellow;"><?php echo @has($success); ?></p><p style="color: red;"><?php echo @has($error1); ?></p><p style="color: red;"><?php echo @has($error2); ?></p></center>
          <table style="width: 100%;">
            <tr>
               <td> <div class="form-group-material">
               <label style="color: white; width: 45%; margin-left: 5px;">Title</label>
               
                <select id="title"  name="title" required data-msg="Please select your title" style="width: 50%; padding: 10px;">
                  <option value="">-select-</option>
                   <option value="Mr.">Mr.</option>
                    <option value="Miss.">Miss.</option>
                     <option value="Mrs.">Mrs.</option>
                      <option value="Dr.">Dr.</option>
                       <option value="Dr. (Mrs.)">Dr. (Mrs.)</option>
                        <option value="Prof.">Prof.</option>
                        <option value="Prof. (Mrs.)">Prof. (Mrs.)</option>
                        <option value="Rev. Fr.">Rev. Fr.</option>
                         <option value="Engr.">Engr.</option>
                          <option value="Engr. (Mrs.)">Engr. (Mrs.)</option>
             
               </select>
              </div></td>
             
            <td> <div class="form-group-material">
               <label style="color: white; width: 45%; margin-left: 5px;">Gender</label>
               
                <select id="gender"  name="gender" required data-msg="Please select Your Gender" style="width: 50%; padding: 10px;">
                  <option value="">-select-</option>
                   <option value="Male">Male</option>
                    <option value="Female">Female</option>
                             
               </select>
              </div></td>
            </tr>
            <tr>
            <td> <div class="form-group-material">
               <label style="color: white; width: 45%; margin-left: 5px;">Country</label>
               
                <select id="Country"  name="country" required data-msg="Please select Your Country" style="width: 50%; padding: 10px;">
                  <option value="">-select-</option>
                   <option value="Nigeria">Nigeria</option>
                    <option value="Ghana">Ghana</option>
                    <option value="Togo">Togo</option>
                    <option value="Zambia">Zambia</option>
                             
               </select>
              </div></td>
             <td style="width: 50%;"> <div class="form-group-material">
                <input id="Surname" type="text" name="username" required data-msg="Please enter your Username" class="input-material">
                <label for="Surname" class="label-material">Username</label>
              </div></td>
            </tr>
            <tr>
             <td style="width: 50%;"> <div class="form-group-material">
                <input id="state" type="text" name="state" required data-msg="Please enter your state" class="input-material">
                <label for="state" class="label-material">State</label>
              </div></td>
             <td> <div class="form-group-material">
                <input id="city" type="text" name="city" required data-msg="Please enter Your City" class="input-material">
                <label for="City" class="label-material">City </label>
              </div></td>
            </tr>
            <tr>
              <td style="width: 50%;"> <div class="form-group-material">
                <input id="register-password" type="password" name="password1" required data-msg="Please enter your password" class="input-material">
                <label for="register-password" class="label-material">Password</label>
              </div></td>
              <td> <div class="form-group-material">
                <input id="register-password2" type="password" name="password2" required data-msg="Please Re-Enter password" class="input-material">
                <label for="register-password2" class="label-material">Re-Enter Password</label>
              </div></td>
            </tr>

            <tr>
             <td> <div class="form-group terms-conditions text-center">
                <input id="register-agree" name="registeragree" type="checkbox" required value="1" data-msg="Your agreement is required" class="form-control-custom">
                <label for="register-agree">I agree with the terms and policy</label>
              </div></td>
             <td><div class="form-group text-center">
                <input id="register" type="reset" value="Reset" class="btn btn-primary">
                 <input id="register" type="submit" value="Register" name="register_student" class="btn btn-primary">
              </div></td>
            </tr>

              </table>
            </form><small>Already have an account? </small><a href="login.php" class="signup">Login</a>
          </div>
          
        </div>
      </div>
    </div>
    <!-- JavaScript files-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/popper.js/umd/popper.min.js"> </script>
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>
    <script src="js/grasp_mobile_progress_circle-1.0.0.min.js"></script>
    <script src="vendor/jquery.cookie/jquery.cookie.js"> </script>
    <script src="vendor/chart.js/Chart.min.js"></script>
    <script src="vendor/jquery-validation/jquery.validate.min.js"></script>
    <script src="vendor/malihu-custom-scrollbar-plugin/jquery.mCustomScrollbar.concat.min.js"></script>
    <!-- Main File-->
    <script src="js/front.js"></script>
  </body>
</html>