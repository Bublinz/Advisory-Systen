   <?php
 require_once 'php/a_assets.php';
   require_once 'php/a_header.php';
  ?>
 

 <!-- Breadcrumb-->
      <div class="breadcrumb-holder">
        <div class="container-fluid">
          <ul class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.html">Home</a></li>
            <li class="breadcrumb-item active">Connections with Mentee</li>
          </ul>
        </div>
      </div>
      <section>
        <div class="container-fluid">
          <!-- Page Header-->
          <header> 
            <h1 class="h3 display">Here are your Mentee - Connection status</h1>
          </header>
          <div class="row">
            <div class="col-lg-6">
              <div class="card">
                <div class="card-header">
                  <h4>Pending Connections</h4>
                </div>
                <div class="card-body">
                  <div class="table-responsive">
                    <table class="table">
                      <thead>
                        <tr>
                          <th>S/N</th>
                          <th>Mentee's name</th>
                          <th>Contact</th>
                          <th>Interest</th>
                           <th>Accept</th>
                        </tr>
                      </thead>
                      <tbody>
                         <?php
                      $prem = fetch("SELECT con.*, men.* FROM ment_connectivity as con LEFT JOIN mentee as men ON con.mm_mentee_id = men.mentee_id $w con.mm_mentor_id = '".$_SESSION['id']."' AND con.mm_con_status='0' ORDER BY con.mm_con_id DESC");
                      if ($prem<=0){
                        echo "<tr ><td colspan='5' style='text-align:center;'>No Pending connections yet</td></tr>";
                      }else{
                        $i=0;
                        foreach($prem as $p){
                          $i++;
                          echo "
                         <tr>
                          <th>$i</th>
                          <td>$p->first_name</td>
                          <td>$p->mobile</td>
                          <td>$p->ment_interest</td>
                          <td><button class='btn btn-warning'><i class='fa fa-book'></i><input type='hidden' value='$p->mm_con_id'></button></td>
                        </tr>
                        ";
                        }
                      }
                      ?>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-lg-6">
              <div class="card">
                <div class="card-header">
                  <h4>Successful Connections</h4>
                </div>
                <div class="card-body">
                  <div class="table-responsive">
                    <table class="table table-striped">
                      <thead>
                        <tr>
                          <th>S/N</th>
                          <th>Mentee's name</th>
                          <th>Contact</th>
                          <th>Interest</th>
                           <th>Action</th>
                        </tr>
                      </thead>
                      <tbody>
                      <?php
                      $prem = fetch("SELECT con.*, men.* FROM ment_connectivity as con LEFT JOIN mentee as men ON con.mm_mentee_id = men.mentee_id $w con.mm_mentor_id = '".$_SESSION['id']."' AND con.mm_con_status='1'  ORDER BY con.mm_con_id DESC");
                      if ($prem<=0){
                        echo "<tr ><td colspan='5' style='text-align:center;'>No successful connections yet</td></tr>";
                      }else{
                        $i=0;
                        foreach($prem as $r){
                          $i++;
                          echo "
                           <tr>
                          <th>$i</th>
                          <td>$r->first_name</td>
                          <td>$r->mobile</td>
                          <td>$r->ment_interest</td>
                          <td><button class='btn btn-danger'><i class='fa fa-trash'></i><input type='hidden' value='$r->mm_con_id'></button></td>
                        </tr>
                          ";
                        }
                      }
                      ?>
                      
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
       <?php require_once('php/a_footer.php');?>