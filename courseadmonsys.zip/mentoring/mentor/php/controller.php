
<?php @session_start();
require_once "database.php";



//login for mentee
if(isset($_POST['mentor_login'])){
	$user = filters('username');
	$pass = filters('password');  
	if ($user!="" and $pass!=""){
$login = counts("$s mentor $w username='$user' and password ='$pass' and status='1'");
	if($login <= 0){
		$error1 = "Wrong Login Credentials !";
	} else { 
		$id = get("mentor_id","$s mentor $w username ='$user' and password ='$pass'");  
	
		$_SESSION['id'] = $id;
	
		to('dash.php');
	}
}
	
} 


//login for mentor_signup1
if(isset($_POST['mentor_signup1'])){
	$last_name = filters('surname');
	$first_name = filters('othernames'); 
	$email = filters('email');
	$phone = filters('phone');  
	$file =$_FILES['file']['name'];
 
	// if (!empty($file)){
		$target_dir = "mentor_cv/";
		$target_file = $target_dir.basename($_FILES["file"]["name"]); 
 	 	move_uploaded_file($_FILES["file"]["tmp_name"], $target_file); 
		$check =counts("$s mentor $w status='1' and (email='$email' or mobile='$phone')");
		if($check<1){
			if(udi("$i mentor values('','','$last_name','$first_name','$email','$file','','$phone','','','','','','','','','','','','','','','','1')")){
			$success="Your details have been received, Check your email for further directions!";		
			}

			else{
			$error="Sorry, Something went wrong !";
			}	
		}else{
			$error="Your Details Have been sent alreay !";
			}

	// }else{
	// $error="Please Select a valid CV for upload !";
	// 	}

	
} 


//Students registration part1 bio data
if(isset($_POST['register_student'])){ 
	$reg_no = filters('reg_no');
	$surname = filters('surname');
	$othernames = filters('othernames');
	$section = filters('section');
	$email = filters('email');
	$phone = filters('phone');
    $password1 = filters('password1');
    $password2 = filters('password2');
	//$city = filters('city');
	//$state = filters('state');
    //$degree = filters('degree');
    //$institution = filters('institution');
    //$studied = filters('studied');
     //$prev_mem = filters('prev_mem');
    //$mem_type = filters('mem_type');
   // $prev_mem_id = filters('prev_mem_id');
   // $mem_year = filters('mem_year');
   // $username = filters('username');
	//$img = $_FILES['img']['name'];
	//$target_dir = "../portal/img/";
	//$target_file = $target_dir.basename($_FILES["img"]["name"]); 
   // move_uploaded_file($_FILES["img"]["tmp_name"], $target_file); 

 if ($password1==$password2) {
 
$search1 = counts("SELECT * FROM students_data WHERE status='1' AND (reg_no='$reg_no' OR email='$email')");
     if($search1 >= 1){
            		$error1 = "User account Exist!!!";
     }
   elseif(udi("$i students_data values('','$surname','$othernames','$reg_no','','$phone','','','','','$email','','','','$section','$password1','3','1')")){
   	$success="Account created Sucessfully!!!";
   }
   else{$error = "Sorry, Something went wrong!!!";}

 }else{
 	$error1 ="Password do not March!!!";
 }
}


//achive student 
if(isset($_POST['archive_student'])){ 
	$student_id = filters('student_id');
    $student_name = filters('student_name');
	if(udi("$u bio_data set status='0' where bd_id='$student_id'")){
		$notifications = "$student_name has been trashed !";
		$task = "<script>$('#notifications').click();</script>"; 
	} else { 
		$notifications = "Something went wrong, $student_name was not removed !"; 
 		$task = "<script>$('#notifications').click();</script>"; 
	}  
}




//achive dept
if(isset($_POST['archive_dept'])){ 
	$dept_id = filters('dept_id'); 
    $dept_name = filters('dept_name');
	if(udi("$u department set status='0' where dept_id='$dept_id'")){
		$notifications = "$dept_name has been trashed !";
		$task = "<script>$('#notifications').click();</script>"; 
	} else { 
		$notifications = "Something went wrong, $dept_name was not removed !"; 
 		$task = "<script>$('#notifications').click();</script>"; 
	}  
}



// add staff 
if(isset($_POST['add_staff'])){ 
	$name = filters('name'); 
	$phone = filters('phone');
	$dept = filters('dept');
	$username = filters('username');
	$password = filters('password');
	$address = filters('address');
	$img = $_FILES['img']['name'];
	$target_dir = "img/";
	$target_file = $target_dir.basename($_FILES["img"]["name"]); 
    move_uploaded_file($_FILES["img"]["tmp_name"], $target_file);   
	    if(udi("$i staff (staff_id,name,phone,img,status,dept_id,address,username,password,role) values('','$name','$phone','$img','1','$dept','$address','$username','$password','2')")){
	    	$notifications = "New Staff has been added to records !";
	    	$task = "<script>$('#notifications').click();</script>"; 
	    } else { 
	    	$notifications = "Something went wrong Staff not saved !"; 
	    	$task = "<script>$('#notifications').click();</script>"; 
	    }  
}


// add new courses
if(isset($_POST['add_course'])){ 
	$title = filters('title');   
	$name = filters('name');
    $desc = filters('desc');
   
	    if(udi("$i course values('','$name','$title','$desc','1')")){
	    	$notifications = "New Course has been added!";
	    	$task = "<script>$('#notifications').click();</script>"; 
	    } else { 
	    	$notifications = "Something went wrong Course not saved !"; 
	    	$task = "<script>$('#notifications').click();</script>"; 
	    }  
}


// Grant assess to write exam
if(isset($_POST['grant_assess'])){ 
	if(!empty($_POST['course'])){
$date = filters('date');   
$reg_no = filters('reg_no');
$course = $_POST['course'];
$courses = implode(' , ', $course);	
if(udi("$i clear values('','$courses','$reg_no','$date','1')")){
	    	$notifications = "Assess Granted Sucessfully! on $date ";
	    	$task = "<script>$('#notifications').click();</script>"; 
	    } else { 
	    	$notifications = "Something went wrong, Assess not granted !"; 
	    	$task = "<script>$('#notifications').click();</script>"; 
	    }  
}
}
//archive_courses 
if(isset($_POST['archive_course'])){ 
	$course_id = filters('course_id'); 
	if(udi("$u course set status='0' where course_id='$course_id'")){
		$notifications = "Course has been trashed !";
		$task = "<script>$('#notifications').click();</script>"; 
	} else { 
		$notifications = "Something went wrong Course records not removed !"; 
 		$task = "<script>$('#notifications').click();</script>"; 
	}  
}


//update_account
if(isset($_POST['update_account'])){ 
	$id = $_SESSION['id']; 
	$name = foilters('name'); 
	$user = foilters('user');
	$pass = foilters('pass');
    $pass1 = filters('pass1');
    $pass11 = filters('pass11');
	@$img = $_FILES['img']['name'];

    $check1 = counts("SELECT * FROM users WHERE user_id = '$id' AND password = '$pass' "); 
    if($check1 <= 0){
      $notifications = "<span style='color:red;'>SORRY, Old Password is not correct!!!</span>";
	    	$task = "<script>$('#notifications').click();</script>";   
    }
    
    elseif ($pass1 != $pass11){
        $notifications = "<span style='color:red;'>SORRY, The New password Must Match</span>";
	    	$task = "<script>$('#notifications').click();</script>";         
    }
	elseif(!empty($img)){          
		$target_dir = "img/";
		$target_file = $target_dir.basename($_FILES["img"]["name"]); 
	    move_uploaded_file($_FILES["img"]["tmp_name"], $target_file);   
	    if(udi("$u users set name='$name',username='$user',password='$pass1',img='$img' where user_id='$id'")){
	    	$notifications = "Account Profile has been updated !";
	    	$task = "<script>$('#notifications').click();</script>"; 
	    } else { 
	    	$notifications = "Something went wrong account not updated step1!"; 
	    	$task = "<script>$('#notifications').click();</script>"; 
	    }  
	}

	 else {  
	    if(udi("$u users set name='$name',username='$user',password='$pass1' where user_id='$id'")){
	    	$notifications = "Account Profile has been updated without Passport!";
	    	$task = "<script>$('#notifications').click();</script>"; 
	    } else { 
	    	$notifications = "Something went wrong account not updated step2!"; 
	    	$task = "<script>$('#notifications').click();</script>"; 
	    }  
	}

}





?>